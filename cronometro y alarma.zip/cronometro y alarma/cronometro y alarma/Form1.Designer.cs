﻿namespace cronometro_y_alarma
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btniniciar = new System.Windows.Forms.Button();
            this.btndetener = new System.Windows.Forms.Button();
            this.btnencerar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.texttiempo = new System.Windows.Forms.TextBox();
            this.Reloj = new System.Windows.Forms.Timer(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.dtphora = new System.Windows.Forms.DateTimePicker();
            this.Alarma = new System.Windows.Forms.Timer(this.components);
            this.dtpfijarhora = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.btnfijaralarma = new System.Windows.Forms.Button();
            this.nuphora = new System.Windows.Forms.NumericUpDown();
            this.nupminuto = new System.Windows.Forms.NumericUpDown();
            this.nupsegundo = new System.Windows.Forms.NumericUpDown();
            this.btnactivar = new System.Windows.Forms.Button();
            this.btndesactivar = new System.Windows.Forms.Button();
            this.Control_Alarma = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nuphora)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupminuto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupsegundo)).BeginInit();
            this.SuspendLayout();
            // 
            // btniniciar
            // 
            this.btniniciar.Location = new System.Drawing.Point(25, 21);
            this.btniniciar.Name = "btniniciar";
            this.btniniciar.Size = new System.Drawing.Size(75, 23);
            this.btniniciar.TabIndex = 0;
            this.btniniciar.Text = "Iniciar";
            this.btniniciar.UseVisualStyleBackColor = true;
            this.btniniciar.Click += new System.EventHandler(this.btniniciar_Click);
            // 
            // btndetener
            // 
            this.btndetener.Location = new System.Drawing.Point(117, 21);
            this.btndetener.Name = "btndetener";
            this.btndetener.Size = new System.Drawing.Size(75, 23);
            this.btndetener.TabIndex = 1;
            this.btndetener.Text = "Detener";
            this.btndetener.UseVisualStyleBackColor = true;
            this.btndetener.Click += new System.EventHandler(this.btndetener_Click);
            // 
            // btnencerar
            // 
            this.btnencerar.Location = new System.Drawing.Point(214, 21);
            this.btnencerar.Name = "btnencerar";
            this.btnencerar.Size = new System.Drawing.Size(75, 23);
            this.btnencerar.TabIndex = 2;
            this.btnencerar.Text = "Encerar";
            this.btnencerar.UseVisualStyleBackColor = true;
            this.btnencerar.Click += new System.EventHandler(this.btnencerar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 69);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Tiempo";
            // 
            // texttiempo
            // 
            this.texttiempo.Location = new System.Drawing.Point(73, 66);
            this.texttiempo.Name = "texttiempo";
            this.texttiempo.Size = new System.Drawing.Size(184, 20);
            this.texttiempo.TabIndex = 4;
            this.texttiempo.Text = "00:00:00.0";
            this.texttiempo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Reloj
            // 
            this.Reloj.Tick += new System.EventHandler(this.Reloj_Tick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Reloj";
            // 
            // dtphora
            // 
            this.dtphora.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtphora.Location = new System.Drawing.Point(89, 101);
            this.dtphora.Name = "dtphora";
            this.dtphora.Size = new System.Drawing.Size(93, 20);
            this.dtphora.TabIndex = 6;
            // 
            // Alarma
            // 
            this.Alarma.Enabled = true;
            this.Alarma.Tick += new System.EventHandler(this.Alarma_Tick);
            // 
            // dtpfijarhora
            // 
            this.dtpfijarhora.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dtpfijarhora.Location = new System.Drawing.Point(89, 133);
            this.dtpfijarhora.Name = "dtpfijarhora";
            this.dtpfijarhora.ShowUpDown = true;
            this.dtpfijarhora.Size = new System.Drawing.Size(103, 20);
            this.dtpfijarhora.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 139);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Fijar Hora";
            // 
            // btnfijaralarma
            // 
            this.btnfijaralarma.Location = new System.Drawing.Point(225, 107);
            this.btnfijaralarma.Name = "btnfijaralarma";
            this.btnfijaralarma.Size = new System.Drawing.Size(75, 55);
            this.btnfijaralarma.TabIndex = 9;
            this.btnfijaralarma.Text = "Fijar Alarma";
            this.btnfijaralarma.UseVisualStyleBackColor = true;
            this.btnfijaralarma.Click += new System.EventHandler(this.btnfijaralarma_Click);
            // 
            // nuphora
            // 
            this.nuphora.Location = new System.Drawing.Point(17, 182);
            this.nuphora.Name = "nuphora";
            this.nuphora.Size = new System.Drawing.Size(39, 20);
            this.nuphora.TabIndex = 10;
            // 
            // nupminuto
            // 
            this.nupminuto.Location = new System.Drawing.Point(73, 182);
            this.nupminuto.Name = "nupminuto";
            this.nupminuto.Size = new System.Drawing.Size(39, 20);
            this.nupminuto.TabIndex = 11;
            // 
            // nupsegundo
            // 
            this.nupsegundo.Location = new System.Drawing.Point(129, 182);
            this.nupsegundo.Name = "nupsegundo";
            this.nupsegundo.Size = new System.Drawing.Size(39, 20);
            this.nupsegundo.TabIndex = 12;
            // 
            // btnactivar
            // 
            this.btnactivar.Location = new System.Drawing.Point(182, 179);
            this.btnactivar.Name = "btnactivar";
            this.btnactivar.Size = new System.Drawing.Size(75, 23);
            this.btnactivar.TabIndex = 13;
            this.btnactivar.Text = "Activar";
            this.btnactivar.UseVisualStyleBackColor = true;
            this.btnactivar.Click += new System.EventHandler(this.btnactivar_Click);
            // 
            // btndesactivar
            // 
            this.btndesactivar.Location = new System.Drawing.Point(182, 219);
            this.btndesactivar.Name = "btndesactivar";
            this.btndesactivar.Size = new System.Drawing.Size(75, 23);
            this.btndesactivar.TabIndex = 14;
            this.btndesactivar.Text = "Desactivar";
            this.btndesactivar.UseVisualStyleBackColor = true;
            this.btndesactivar.Click += new System.EventHandler(this.btndesactivar_Click);
            // 
            // Control_Alarma
            // 
            this.Control_Alarma.Enabled = true;
            this.Control_Alarma.Tick += new System.EventHandler(this.Control_Alarma_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 324);
            this.Controls.Add(this.btndesactivar);
            this.Controls.Add(this.btnactivar);
            this.Controls.Add(this.nupsegundo);
            this.Controls.Add(this.nupminuto);
            this.Controls.Add(this.nuphora);
            this.Controls.Add(this.btnfijaralarma);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dtpfijarhora);
            this.Controls.Add(this.dtphora);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.texttiempo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnencerar);
            this.Controls.Add(this.btndetener);
            this.Controls.Add(this.btniniciar);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nuphora)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupminuto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupsegundo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btniniciar;
        private System.Windows.Forms.Button btndetener;
        private System.Windows.Forms.Button btnencerar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox texttiempo;
        private System.Windows.Forms.Timer Reloj;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtphora;
        private System.Windows.Forms.Timer Alarma;
        private System.Windows.Forms.DateTimePicker dtpfijarhora;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnfijaralarma;
        private System.Windows.Forms.NumericUpDown nuphora;
        private System.Windows.Forms.NumericUpDown nupminuto;
        private System.Windows.Forms.NumericUpDown nupsegundo;
        private System.Windows.Forms.Button btnactivar;
        private System.Windows.Forms.Button btndesactivar;
        private System.Windows.Forms.Timer Control_Alarma;
    }
}

