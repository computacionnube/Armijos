﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace cronometro_y_alarma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int dd, ss, mm, hh=0;
        int sb, mb, hb = 0; 
        int fa = 0;

        private void btniniciar_Click(object sender, EventArgs e)
        {
            Reloj.Start();
        }

        private void Reloj_Tick(object sender, EventArgs e)
        {
            string ht, mt, st;
            dd++;
            if(dd==10)
            {
                dd = 0;
                ss++;
                if (ss == 60)
                {
                    mm++;
                    ss = 0;
                }
                if (mm == 60)
                {
                    hh++;
                    mm = 0;
                }
            }
            if (hh < 10) ht = "0" + Convert.ToString(hh);
            else ht = Convert.ToString(hh);
            if (mm < 10) mt = "0" + Convert.ToString(mm);
            else mt = Convert.ToString(mm);
            if(ss < 10) st = "0" +Convert.ToString(ss);
            else st = Convert.ToString(ss);
            texttiempo.Text = ht + ":" + mt + ":" + st + "." + Convert.ToString(dd); 
        }
        private void btndetener_Click(object sender, EventArgs e)
        {
            Reloj.Stop();
        }

        private void btnencerar_Click(object sender, EventArgs e)
        {
            Reloj.Stop();
            dd = ss = mm = hh = 0;
            texttiempo.Clear();
            texttiempo.Text = "00:00:00.0";
        }

        private void Alarma_Tick(object sender, EventArgs e)
        {
            dtphora.Value = DateTime.Now;
            if (fa == 1){
                if (dtphora.Value.Second == dtpfijarhora.Value.Second && dtphora.Value.Minute == dtpfijarhora.Value.Minute && dtphora.Value.Hour == dtphora.Value.Hour)
                {
                    fa = 0;
                    MessageBox.Show("Alarma");
                }
            }
        }
        private void btnfijaralarma_Click(object sender, EventArgs e)
        {
            fa = 1;
        }

        private void Control_Alarma_Tick(object sender, EventArgs e)
        {
            sb--;
            if (sb <= 0)
            {
                if (mb > 0)
                {
                    mb--;
                    sb = 59;
                }
            }
            if (mb == 0)
            {
                if(hb > 0)
                {
                    hb--;
                    mb = 59;
                }
            }
            nuphora.Value = Convert.ToDecimal(hb);
            nupminuto.Value = Convert.ToDecimal(mb);
            nupsegundo.Value = Convert.ToDecimal(sb);
            if (sb == 0 && mb == 0 && hb == 0)
            {
                Control_Alarma.Stop();
                MessageBox.Show("Termino el tiempo", "Control_Tiempo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            
            //if(sb==60)
            //{
            //    mb--;
            //    ss=0;
            //    if (mm == 60)
            //    {
            //        hh--;
            //        mm = 0;
            //    }
            //}

        }
        private void btnactivar_Click(object sender, EventArgs e)
        {
            sb = Convert.ToInt32(nupsegundo.Value);
            mb = Convert.ToInt32(nupminuto.Value);
            hb = Convert.ToInt32(nuphora.Value);
            Control_Alarma.Start();

        }
        private void btndesactivar_Click(object sender, EventArgs e)
        {
            Control_Alarma.Stop();
        }
         
    }
}
