﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Label10 = new System.Windows.Forms.Label();
            this.dgvRes = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NOMBRE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.APELLIDO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nacimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FECHANACI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NACIONALIDA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ESTADCIVI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pais = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtNacionalid = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.txtNombres = new System.Windows.Forms.TextBox();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.txtLugarNacim = new System.Windows.Forms.TextBox();
            this.txtApellidosNaci = new System.Windows.Forms.TextBox();
            this.txtPaisNacim = new System.Windows.Forms.TextBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.datapFechaNa = new System.Windows.Forms.DateTimePicker();
            this.chksoltero = new System.Windows.Forms.CheckBox();
            this.chkcasado = new System.Windows.Forms.CheckBox();
            this.chkseparado = new System.Windows.Forms.CheckBox();
            this.chkdivorsiado = new System.Windows.Forms.CheckBox();
            this.chkviuda = new System.Windows.Forms.CheckBox();
            this.chkotros = new System.Windows.Forms.CheckBox();
            this.p1 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.txtNaTuMen = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtDirMenor = new System.Windows.Forms.TextBox();
            this.txtNomMenor = new System.Windows.Forms.TextBox();
            this.txtApMenor = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtDomicilio = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtNumDocumentoIden = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.chkPasaOrdin = new System.Windows.Forms.CheckBox();
            this.chkPasaDiplo = new System.Windows.Forms.CheckBox();
            this.chkPasaServicio = new System.Windows.Forms.CheckBox();
            this.chkDocViaje = new System.Windows.Forms.CheckBox();
            this.chkPasaEspecial = new System.Windows.Forms.CheckBox();
            this.chkPasaOficial = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtNumDocuViaje = new System.Windows.Forms.TextBox();
            this.txtFeExpedicion = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtValidohast = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtExpedidopor = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtCalles = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtResidpaisdis = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtNumTelefono = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSalirReserva = new System.Windows.Forms.Button();
            this.dgvReserva = new System.Windows.Forms.DataGridView();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnModificaReserva = new System.Windows.Forms.Button();
            this.btnGuardaReserva = new System.Windows.Forms.Button();
            this.chkExpedidoDe = new System.Windows.Forms.CheckBox();
            this.chkDenegado = new System.Windows.Forms.CheckBox();
            this.chkOtroDoc = new System.Windows.Forms.CheckBox();
            this.chkSeguroMedico = new System.Windows.Forms.CheckBox();
            this.chkMediosTrans = new System.Windows.Forms.CheckBox();
            this.chkInvitacion = new System.Windows.Forms.CheckBox();
            this.chkMediosSub = new System.Windows.Forms.CheckBox();
            this.chkDocuViaj = new System.Windows.Forms.CheckBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.chkOtro = new System.Windows.Forms.CheckBox();
            this.chkFrontera = new System.Windows.Forms.CheckBox();
            this.chkIntermediario = new System.Windows.Forms.CheckBox();
            this.chkProveerdor = new System.Windows.Forms.CheckBox();
            this.chkCcs = new System.Windows.Forms.CheckBox();
            this.chkEmbajada = new System.Windows.Forms.CheckBox();
            this.txtNumSolicitud = new System.Windows.Forms.TextBox();
            this.txtFSolicitud = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.chkMujer = new System.Windows.Forms.CheckBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.chkVaron = new System.Windows.Forms.CheckBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRes)).BeginInit();
            this.p1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReserva)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(33, 173);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(115, 13);
            this.Label10.TabIndex = 2;
            this.Label10.Text = "Apellido de Nacimiento";
            // 
            // dgvRes
            // 
            this.dgvRes.BackgroundColor = System.Drawing.Color.Gray;
            this.dgvRes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.NOMBRE,
            this.APELLIDO,
            this.Column11,
            this.Column19,
            this.Column12,
            this.Column20,
            this.Column21,
            this.Column2,
            this.nacimiento,
            this.FECHANACI,
            this.NACIONALIDA,
            this.sex,
            this.ESTADCIVI,
            this.pais,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column18,
            this.Column8,
            this.Column9,
            this.Column10});
            this.dgvRes.Location = new System.Drawing.Point(17, 621);
            this.dgvRes.Name = "dgvRes";
            this.dgvRes.Size = new System.Drawing.Size(826, 99);
            this.dgvRes.TabIndex = 54;
            this.dgvRes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvRes_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Apellido";
            this.Column1.Name = "Column1";
            // 
            // NOMBRE
            // 
            this.NOMBRE.HeaderText = "Nombres";
            this.NOMBRE.Name = "NOMBRE";
            // 
            // APELLIDO
            // 
            this.APELLIDO.HeaderText = "Apellidos de Nacimiento";
            this.APELLIDO.Name = "APELLIDO";
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Fecha Nacimiento";
            this.Column11.Name = "Column11";
            // 
            // Column19
            // 
            this.Column19.HeaderText = "DatosMenor Edad Apellido";
            this.Column19.Name = "Column19";
            // 
            // Column12
            // 
            this.Column12.HeaderText = "DatosMenor Edad Nombre";
            this.Column12.Name = "Column12";
            // 
            // Column20
            // 
            this.Column20.HeaderText = "DatosMenor Edad Direccion";
            this.Column20.Name = "Column20";
            // 
            // Column21
            // 
            this.Column21.HeaderText = "DatosMenor Edad Naciona Tutor";
            this.Column21.Name = "Column21";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Domicilio";
            this.Column2.Name = "Column2";
            // 
            // nacimiento
            // 
            this.nacimiento.HeaderText = "Lugar de Nacimiento";
            this.nacimiento.Name = "nacimiento";
            // 
            // FECHANACI
            // 
            this.FECHANACI.HeaderText = "Pais Nacimiento";
            this.FECHANACI.Name = "FECHANACI";
            // 
            // NACIONALIDA
            // 
            this.NACIONALIDA.HeaderText = "Nacionalidad";
            this.NACIONALIDA.Name = "NACIONALIDA";
            // 
            // sex
            // 
            this.sex.HeaderText = "Sexo";
            this.sex.Name = "sex";
            // 
            // ESTADCIVI
            // 
            this.ESTADCIVI.HeaderText = "Estado Civil";
            this.ESTADCIVI.Name = "ESTADCIVI";
            // 
            // pais
            // 
            this.pais.HeaderText = "Num Documento Identidad";
            this.pais.Name = "pais";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Tipo Doc De Viaje";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Num Doc de Viaje";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Fecha de Expedicion";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Valido hasta";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Expedido por";
            this.Column7.Name = "Column7";
            // 
            // Column18
            // 
            this.Column18.HeaderText = "Domicilio del Solicitante";
            this.Column18.Name = "Column18";
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Correo del Solicitante";
            this.Column8.Name = "Column8";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Residencia Pais Distinto";
            this.Column9.Name = "Column9";
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Numero Telefono";
            this.Column10.Name = "Column10";
            // 
            // txtNacionalid
            // 
            this.txtNacionalid.Location = new System.Drawing.Point(146, 343);
            this.txtNacionalid.Name = "txtNacionalid";
            this.txtNacionalid.Size = new System.Drawing.Size(100, 20);
            this.txtNacionalid.TabIndex = 14;
            this.txtNacionalid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNacionalid_KeyPress);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(32, 343);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(72, 13);
            this.Label9.TabIndex = 13;
            this.Label9.Text = "Nacionalidad:";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(230, 18);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(62, 13);
            this.Label8.TabIndex = 6;
            this.Label8.Text = "Estado Civil";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(30, 313);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(98, 13);
            this.Label6.TabIndex = 11;
            this.Label6.Text = "Pais de Nacimiento";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(30, 286);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(105, 13);
            this.Label5.TabIndex = 9;
            this.Label5.Text = "Lugar de Nacimiento";
            // 
            // txtNombres
            // 
            this.txtNombres.Enabled = false;
            this.txtNombres.Location = new System.Drawing.Point(146, 201);
            this.txtNombres.Name = "txtNombres";
            this.txtNombres.Size = new System.Drawing.Size(100, 20);
            this.txtNombres.TabIndex = 5;
            this.txtNombres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombres_KeyPress);
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(146, 136);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(100, 20);
            this.txtApellido.TabIndex = 1;
            this.txtApellido.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtApellidoCo_KeyPress);
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(33, 232);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(109, 13);
            this.Label4.TabIndex = 6;
            this.Label4.Text = "Fecha de nacimiento:";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(33, 143);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(49, 13);
            this.Label3.TabIndex = 0;
            this.Label3.Text = "Apellidos";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(33, 201);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(52, 13);
            this.Label2.TabIndex = 4;
            this.Label2.Text = "Nombres:";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(379, 54);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(322, 36);
            this.Label1.TabIndex = 38;
            this.Label1.Text = "SOLICITUD DE VISADO";
            // 
            // txtLugarNacim
            // 
            this.txtLugarNacim.Location = new System.Drawing.Point(146, 283);
            this.txtLugarNacim.Name = "txtLugarNacim";
            this.txtLugarNacim.Size = new System.Drawing.Size(100, 20);
            this.txtLugarNacim.TabIndex = 10;
            // 
            // txtApellidosNaci
            // 
            this.txtApellidosNaci.Location = new System.Drawing.Point(146, 170);
            this.txtApellidosNaci.Name = "txtApellidosNaci";
            this.txtApellidosNaci.Size = new System.Drawing.Size(100, 20);
            this.txtApellidosNaci.TabIndex = 3;
            this.txtApellidosNaci.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtApellidos_KeyPress);
            // 
            // txtPaisNacim
            // 
            this.txtPaisNacim.Location = new System.Drawing.Point(146, 313);
            this.txtPaisNacim.Name = "txtPaisNacim";
            this.txtPaisNacim.Size = new System.Drawing.Size(100, 20);
            this.txtPaisNacim.TabIndex = 12;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.Location = new System.Drawing.Point(287, 136);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 54;
            this.btnGuardar.Text = "GUARDAR";
            this.toolTip1.SetToolTip(this.btnGuardar, "Guardar Solicitud");
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnModificar
            // 
            this.btnModificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificar.Location = new System.Drawing.Point(287, 173);
            this.btnModificar.Name = "btnModificar";
            this.btnModificar.Size = new System.Drawing.Size(75, 23);
            this.btnModificar.TabIndex = 55;
            this.btnModificar.Text = "MODIFICAR";
            this.toolTip1.SetToolTip(this.btnModificar, "Modifica Solicitud");
            this.btnModificar.UseVisualStyleBackColor = true;
            this.btnModificar.Click += new System.EventHandler(this.btnModificar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Location = new System.Drawing.Point(287, 216);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(75, 23);
            this.btnSalir.TabIndex = 57;
            this.btnSalir.Text = "SALIR";
            this.toolTip1.SetToolTip(this.btnSalir, "Salir de Aplicacion ");
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // datapFechaNa
            // 
            this.datapFechaNa.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datapFechaNa.Location = new System.Drawing.Point(146, 227);
            this.datapFechaNa.Name = "datapFechaNa";
            this.datapFechaNa.Size = new System.Drawing.Size(100, 20);
            this.datapFechaNa.TabIndex = 7;
            this.datapFechaNa.ValueChanged += new System.EventHandler(this.datapFechaNa_ValueChanged);
            // 
            // chksoltero
            // 
            this.chksoltero.AutoSize = true;
            this.chksoltero.Location = new System.Drawing.Point(344, 13);
            this.chksoltero.Name = "chksoltero";
            this.chksoltero.Size = new System.Drawing.Size(70, 17);
            this.chksoltero.TabIndex = 7;
            this.chksoltero.Text = "Soltero/a";
            this.chksoltero.UseVisualStyleBackColor = true;
            // 
            // chkcasado
            // 
            this.chkcasado.AutoSize = true;
            this.chkcasado.Location = new System.Drawing.Point(344, 35);
            this.chkcasado.Name = "chkcasado";
            this.chkcasado.Size = new System.Drawing.Size(73, 17);
            this.chkcasado.TabIndex = 8;
            this.chkcasado.Text = "Casado/a";
            this.chkcasado.UseVisualStyleBackColor = true;
            // 
            // chkseparado
            // 
            this.chkseparado.AutoSize = true;
            this.chkseparado.Location = new System.Drawing.Point(423, 11);
            this.chkseparado.Name = "chkseparado";
            this.chkseparado.Size = new System.Drawing.Size(83, 17);
            this.chkseparado.TabIndex = 22;
            this.chkseparado.Text = "Separado/a";
            this.chkseparado.UseVisualStyleBackColor = true;
            // 
            // chkdivorsiado
            // 
            this.chkdivorsiado.AutoSize = true;
            this.chkdivorsiado.Location = new System.Drawing.Point(423, 35);
            this.chkdivorsiado.Name = "chkdivorsiado";
            this.chkdivorsiado.Size = new System.Drawing.Size(87, 17);
            this.chkdivorsiado.TabIndex = 23;
            this.chkdivorsiado.Text = "Divorsiado/a";
            this.chkdivorsiado.UseVisualStyleBackColor = true;
            // 
            // chkviuda
            // 
            this.chkviuda.AutoSize = true;
            this.chkviuda.Location = new System.Drawing.Point(535, 11);
            this.chkviuda.Name = "chkviuda";
            this.chkviuda.Size = new System.Drawing.Size(64, 17);
            this.chkviuda.TabIndex = 24;
            this.chkviuda.Text = "Viudo/a";
            this.chkviuda.UseVisualStyleBackColor = true;
            // 
            // chkotros
            // 
            this.chkotros.AutoSize = true;
            this.chkotros.Location = new System.Drawing.Point(535, 35);
            this.chkotros.Name = "chkotros";
            this.chkotros.Size = new System.Drawing.Size(51, 17);
            this.chkotros.TabIndex = 25;
            this.chkotros.Text = "Otros";
            this.chkotros.UseVisualStyleBackColor = true;
            // 
            // p1
            // 
            this.p1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.p1.Controls.Add(this.label16);
            this.p1.Controls.Add(this.txtNaTuMen);
            this.p1.Controls.Add(this.label15);
            this.p1.Controls.Add(this.label12);
            this.p1.Controls.Add(this.txtDirMenor);
            this.p1.Controls.Add(this.txtNomMenor);
            this.p1.Controls.Add(this.txtApMenor);
            this.p1.Controls.Add(this.label14);
            this.p1.Controls.Add(this.label13);
            this.p1.Enabled = false;
            this.p1.Location = new System.Drawing.Point(394, 131);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(307, 163);
            this.p1.TabIndex = 74;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(16, 13);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(279, 18);
            this.label16.TabIndex = 9;
            this.label16.Text = "DATOS PARA MENORES DE EDAD";
            // 
            // txtNaTuMen
            // 
            this.txtNaTuMen.Location = new System.Drawing.Point(146, 118);
            this.txtNaTuMen.Name = "txtNaTuMen";
            this.txtNaTuMen.Size = new System.Drawing.Size(100, 20);
            this.txtNaTuMen.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(32, 125);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(114, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "Nacionalidad del Tutor";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(32, 95);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "Direccion";
            // 
            // txtDirMenor
            // 
            this.txtDirMenor.Location = new System.Drawing.Point(146, 92);
            this.txtDirMenor.Name = "txtDirMenor";
            this.txtDirMenor.Size = new System.Drawing.Size(100, 20);
            this.txtDirMenor.TabIndex = 2;
            // 
            // txtNomMenor
            // 
            this.txtNomMenor.Location = new System.Drawing.Point(146, 61);
            this.txtNomMenor.Name = "txtNomMenor";
            this.txtNomMenor.Size = new System.Drawing.Size(100, 20);
            this.txtNomMenor.TabIndex = 1;
            // 
            // txtApMenor
            // 
            this.txtApMenor.Location = new System.Drawing.Point(146, 34);
            this.txtApMenor.Name = "txtApMenor";
            this.txtApMenor.Size = new System.Drawing.Size(100, 20);
            this.txtApMenor.TabIndex = 0;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(32, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "Nombre";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 13);
            this.label13.TabIndex = 0;
            this.label13.Text = "Apellidos";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(33, 262);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 13);
            this.label11.TabIndex = 8;
            this.label11.Text = "Domicilio";
            // 
            // txtDomicilio
            // 
            this.txtDomicilio.Location = new System.Drawing.Point(146, 257);
            this.txtDomicilio.Name = "txtDomicilio";
            this.txtDomicilio.Size = new System.Drawing.Size(100, 20);
            this.txtDomicilio.TabIndex = 8;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(22, 391);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(179, 13);
            this.label17.TabIndex = 26;
            this.label17.Text = "Numero de Documento de Identidad";
            // 
            // txtNumDocumentoIden
            // 
            this.txtNumDocumentoIden.Location = new System.Drawing.Point(208, 384);
            this.txtNumDocumentoIden.Name = "txtNumDocumentoIden";
            this.txtNumDocumentoIden.Size = new System.Drawing.Size(100, 20);
            this.txtNumDocumentoIden.TabIndex = 27;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(3, 16);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(127, 13);
            this.label18.TabIndex = 28;
            this.label18.Text = "Tipo Documento de Viaje";
            // 
            // chkPasaOrdin
            // 
            this.chkPasaOrdin.AutoSize = true;
            this.chkPasaOrdin.Location = new System.Drawing.Point(157, 16);
            this.chkPasaOrdin.Name = "chkPasaOrdin";
            this.chkPasaOrdin.Size = new System.Drawing.Size(125, 17);
            this.chkPasaOrdin.TabIndex = 29;
            this.chkPasaOrdin.Text = "Pasaporte Ordinadrio";
            this.chkPasaOrdin.UseVisualStyleBackColor = true;
            // 
            // chkPasaDiplo
            // 
            this.chkPasaDiplo.AutoSize = true;
            this.chkPasaDiplo.Location = new System.Drawing.Point(157, 39);
            this.chkPasaDiplo.Name = "chkPasaDiplo";
            this.chkPasaDiplo.Size = new System.Drawing.Size(132, 17);
            this.chkPasaDiplo.TabIndex = 30;
            this.chkPasaDiplo.Text = "Pasaporte Diplomático";
            this.chkPasaDiplo.UseVisualStyleBackColor = true;
            // 
            // chkPasaServicio
            // 
            this.chkPasaServicio.AutoSize = true;
            this.chkPasaServicio.Location = new System.Drawing.Point(157, 63);
            this.chkPasaServicio.Name = "chkPasaServicio";
            this.chkPasaServicio.Size = new System.Drawing.Size(130, 17);
            this.chkPasaServicio.TabIndex = 31;
            this.chkPasaServicio.Text = "Pasaporte de Servicio";
            this.chkPasaServicio.UseVisualStyleBackColor = true;
            // 
            // chkDocViaje
            // 
            this.chkDocViaje.AutoSize = true;
            this.chkDocViaje.Location = new System.Drawing.Point(300, 63);
            this.chkDocViaje.Name = "chkDocViaje";
            this.chkDocViaje.Size = new System.Drawing.Size(145, 17);
            this.chkDocViaje.TabIndex = 34;
            this.chkDocViaje.Text = "Otro Documento de Viaje";
            this.chkDocViaje.UseVisualStyleBackColor = true;
            // 
            // chkPasaEspecial
            // 
            this.chkPasaEspecial.AutoSize = true;
            this.chkPasaEspecial.Location = new System.Drawing.Point(300, 38);
            this.chkPasaEspecial.Name = "chkPasaEspecial";
            this.chkPasaEspecial.Size = new System.Drawing.Size(117, 17);
            this.chkPasaEspecial.TabIndex = 33;
            this.chkPasaEspecial.Text = "Pasaporte Especial";
            this.chkPasaEspecial.UseVisualStyleBackColor = true;
            // 
            // chkPasaOficial
            // 
            this.chkPasaOficial.AutoSize = true;
            this.chkPasaOficial.Location = new System.Drawing.Point(300, 15);
            this.chkPasaOficial.Name = "chkPasaOficial";
            this.chkPasaOficial.Size = new System.Drawing.Size(106, 17);
            this.chkPasaOficial.TabIndex = 32;
            this.chkPasaOficial.Text = "Pasaporte Oficial";
            this.chkPasaOficial.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(19, 469);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(158, 13);
            this.label19.TabIndex = 35;
            this.label19.Text = "Numero de Documento de Viaje";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(289, 466);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(107, 13);
            this.label20.TabIndex = 37;
            this.label20.Text = "Fecha de Expedicion";
            // 
            // txtNumDocuViaje
            // 
            this.txtNumDocuViaje.Location = new System.Drawing.Point(183, 466);
            this.txtNumDocuViaje.Name = "txtNumDocuViaje";
            this.txtNumDocuViaje.Size = new System.Drawing.Size(100, 20);
            this.txtNumDocuViaje.TabIndex = 36;
            this.txtNumDocuViaje.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumDocuViaje_KeyPress);
            // 
            // txtFeExpedicion
            // 
            this.txtFeExpedicion.Location = new System.Drawing.Point(394, 462);
            this.txtFeExpedicion.Name = "txtFeExpedicion";
            this.txtFeExpedicion.Size = new System.Drawing.Size(100, 20);
            this.txtFeExpedicion.TabIndex = 38;
            this.txtFeExpedicion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFeExpedicion_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(504, 465);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 13);
            this.label21.TabIndex = 39;
            this.label21.Text = "Valido hasta";
            // 
            // txtValidohast
            // 
            this.txtValidohast.Location = new System.Drawing.Point(566, 462);
            this.txtValidohast.Name = "txtValidohast";
            this.txtValidohast.Size = new System.Drawing.Size(100, 20);
            this.txtValidohast.TabIndex = 40;
            this.txtValidohast.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValidohast_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(672, 465);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 13);
            this.label22.TabIndex = 41;
            this.label22.Text = "Expedido por ";
            // 
            // txtExpedidopor
            // 
            this.txtExpedidopor.Location = new System.Drawing.Point(743, 462);
            this.txtExpedidopor.Name = "txtExpedidopor";
            this.txtExpedidopor.Size = new System.Drawing.Size(100, 20);
            this.txtExpedidopor.TabIndex = 42;
            this.txtExpedidopor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExpedidopor_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(22, 598);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(253, 13);
            this.label23.TabIndex = 43;
            this.label23.Text = "Domicilio portal y direccion de correo del solicitante  ";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 26);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 13);
            this.label24.TabIndex = 44;
            this.label24.Text = "Calles";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 48);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(94, 13);
            this.label26.TabIndex = 46;
            this.label26.Text = "Correo Electronico";
            // 
            // txtCalles
            // 
            this.txtCalles.Location = new System.Drawing.Point(107, 23);
            this.txtCalles.Name = "txtCalles";
            this.txtCalles.Size = new System.Drawing.Size(100, 20);
            this.txtCalles.TabIndex = 45;
            this.txtCalles.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCalles_KeyPress);
            // 
            // txtCorreo
            // 
            this.txtCorreo.Location = new System.Drawing.Point(107, 45);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(100, 20);
            this.txtCorreo.TabIndex = 47;
            this.txtCorreo.Leave += new System.EventHandler(this.txtCorreo_Leave);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(9, 78);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(292, 13);
            this.label27.TabIndex = 48;
            this.label27.Text = "Residente de un pais distinto del pais de nacionalidad actual";
            // 
            // txtResidpaisdis
            // 
            this.txtResidpaisdis.Location = new System.Drawing.Point(307, 71);
            this.txtResidpaisdis.Name = "txtResidpaisdis";
            this.txtResidpaisdis.Size = new System.Drawing.Size(100, 20);
            this.txtResidpaisdis.TabIndex = 49;
            this.txtResidpaisdis.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtResidpaisdis_KeyPress);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(5, 111);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(107, 13);
            this.label28.TabIndex = 50;
            this.label28.Text = "Numero de Telefono ";
            // 
            // txtNumTelefono
            // 
            this.txtNumTelefono.Location = new System.Drawing.Point(118, 100);
            this.txtNumTelefono.Name = "txtNumTelefono";
            this.txtNumTelefono.Size = new System.Drawing.Size(123, 20);
            this.txtNumTelefono.TabIndex = 51;
            this.txtNumTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumTelefono_KeyPress);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnSalirReserva);
            this.panel1.Controls.Add(this.dgvReserva);
            this.panel1.Controls.Add(this.btnModificaReserva);
            this.panel1.Controls.Add(this.btnGuardaReserva);
            this.panel1.Controls.Add(this.chkExpedidoDe);
            this.panel1.Controls.Add(this.chkDenegado);
            this.panel1.Controls.Add(this.chkOtroDoc);
            this.panel1.Controls.Add(this.chkSeguroMedico);
            this.panel1.Controls.Add(this.chkMediosTrans);
            this.panel1.Controls.Add(this.chkInvitacion);
            this.panel1.Controls.Add(this.chkMediosSub);
            this.panel1.Controls.Add(this.chkDocuViaj);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.chkOtro);
            this.panel1.Controls.Add(this.chkFrontera);
            this.panel1.Controls.Add(this.chkIntermediario);
            this.panel1.Controls.Add(this.chkProveerdor);
            this.panel1.Controls.Add(this.chkCcs);
            this.panel1.Controls.Add(this.chkEmbajada);
            this.panel1.Controls.Add(this.txtNumSolicitud);
            this.panel1.Controls.Add(this.txtFSolicitud);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Location = new System.Drawing.Point(870, 136);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(539, 644);
            this.panel1.TabIndex = 57;
            // 
            // btnSalirReserva
            // 
            this.btnSalirReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalirReserva.Location = new System.Drawing.Point(390, 394);
            this.btnSalirReserva.Name = "btnSalirReserva";
            this.btnSalirReserva.Size = new System.Drawing.Size(75, 23);
            this.btnSalirReserva.TabIndex = 111;
            this.btnSalirReserva.Text = "SALIR";
            this.toolTip1.SetToolTip(this.btnSalirReserva, "Salir dela Reserva");
            this.btnSalirReserva.UseVisualStyleBackColor = true;
            this.btnSalirReserva.Click += new System.EventHandler(this.btnSalirReserva_Click);
            // 
            // dgvReserva
            // 
            this.dgvReserva.BackgroundColor = System.Drawing.Color.Gray;
            this.dgvReserva.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReserva.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17});
            this.dgvReserva.Location = new System.Drawing.Point(19, 479);
            this.dgvReserva.Name = "dgvReserva";
            this.dgvReserva.Size = new System.Drawing.Size(472, 133);
            this.dgvReserva.TabIndex = 0;
            this.dgvReserva.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvReserva_CellClick);
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Fecha Solicitud";
            this.Column13.Name = "Column13";
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Num de Solicitud";
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.HeaderText = "Solicitud Presenta";
            this.Column15.Name = "Column15";
            // 
            // Column16
            // 
            this.Column16.HeaderText = "Documentos Presentados ";
            this.Column16.Name = "Column16";
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Decision de Visado";
            this.Column17.Name = "Column17";
            // 
            // btnModificaReserva
            // 
            this.btnModificaReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnModificaReserva.Location = new System.Drawing.Point(390, 361);
            this.btnModificaReserva.Name = "btnModificaReserva";
            this.btnModificaReserva.Size = new System.Drawing.Size(75, 23);
            this.btnModificaReserva.TabIndex = 109;
            this.btnModificaReserva.Text = "MODIFICAR";
            this.toolTip1.SetToolTip(this.btnModificaReserva, "Modifica Reserva");
            this.btnModificaReserva.UseVisualStyleBackColor = true;
            this.btnModificaReserva.Click += new System.EventHandler(this.btnModificaReserva_Click);
            // 
            // btnGuardaReserva
            // 
            this.btnGuardaReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardaReserva.Location = new System.Drawing.Point(390, 329);
            this.btnGuardaReserva.Name = "btnGuardaReserva";
            this.btnGuardaReserva.Size = new System.Drawing.Size(75, 23);
            this.btnGuardaReserva.TabIndex = 108;
            this.btnGuardaReserva.Text = "GUARDAR";
            this.toolTip1.SetToolTip(this.btnGuardaReserva, "Guarda Reserva");
            this.btnGuardaReserva.UseVisualStyleBackColor = true;
            this.btnGuardaReserva.Click += new System.EventHandler(this.btnGuardaReserva_Click);
            // 
            // chkExpedidoDe
            // 
            this.chkExpedidoDe.AutoSize = true;
            this.chkExpedidoDe.Location = new System.Drawing.Point(19, 456);
            this.chkExpedidoDe.Name = "chkExpedidoDe";
            this.chkExpedidoDe.Size = new System.Drawing.Size(70, 17);
            this.chkExpedidoDe.TabIndex = 25;
            this.chkExpedidoDe.Text = "Expedido";
            this.chkExpedidoDe.UseVisualStyleBackColor = true;
            // 
            // chkDenegado
            // 
            this.chkDenegado.AutoSize = true;
            this.chkDenegado.Location = new System.Drawing.Point(19, 437);
            this.chkDenegado.Name = "chkDenegado";
            this.chkDenegado.Size = new System.Drawing.Size(76, 17);
            this.chkDenegado.TabIndex = 24;
            this.chkDenegado.Text = "Denegado";
            this.chkDenegado.UseVisualStyleBackColor = true;
            // 
            // chkOtroDoc
            // 
            this.chkOtroDoc.AutoSize = true;
            this.chkOtroDoc.Location = new System.Drawing.Point(168, 383);
            this.chkOtroDoc.Name = "chkOtroDoc";
            this.chkOtroDoc.Size = new System.Drawing.Size(51, 17);
            this.chkOtroDoc.TabIndex = 23;
            this.chkOtroDoc.Text = "Otros";
            this.chkOtroDoc.UseVisualStyleBackColor = true;
            // 
            // chkSeguroMedico
            // 
            this.chkSeguroMedico.AutoSize = true;
            this.chkSeguroMedico.Location = new System.Drawing.Point(168, 364);
            this.chkSeguroMedico.Name = "chkSeguroMedico";
            this.chkSeguroMedico.Size = new System.Drawing.Size(137, 17);
            this.chkSeguroMedico.TabIndex = 22;
            this.chkSeguroMedico.Text = "Seguro médico de viaje";
            this.chkSeguroMedico.UseVisualStyleBackColor = true;
            // 
            // chkMediosTrans
            // 
            this.chkMediosTrans.AutoSize = true;
            this.chkMediosTrans.Location = new System.Drawing.Point(168, 340);
            this.chkMediosTrans.Name = "chkMediosTrans";
            this.chkMediosTrans.Size = new System.Drawing.Size(131, 17);
            this.chkMediosTrans.TabIndex = 20;
            this.chkMediosTrans.Text = "Medios de Transposte";
            this.chkMediosTrans.UseVisualStyleBackColor = true;
            // 
            // chkInvitacion
            // 
            this.chkInvitacion.AutoSize = true;
            this.chkInvitacion.Location = new System.Drawing.Point(24, 386);
            this.chkInvitacion.Name = "chkInvitacion";
            this.chkInvitacion.Size = new System.Drawing.Size(72, 17);
            this.chkInvitacion.TabIndex = 18;
            this.chkInvitacion.Text = "Invitacion";
            this.chkInvitacion.UseVisualStyleBackColor = true;
            // 
            // chkMediosSub
            // 
            this.chkMediosSub.AutoSize = true;
            this.chkMediosSub.Location = new System.Drawing.Point(24, 367);
            this.chkMediosSub.Name = "chkMediosSub";
            this.chkMediosSub.Size = new System.Drawing.Size(136, 17);
            this.chkMediosSub.TabIndex = 17;
            this.chkMediosSub.Text = "Medios de subsistencia";
            this.chkMediosSub.UseVisualStyleBackColor = true;
            // 
            // chkDocuViaj
            // 
            this.chkDocuViaj.AutoSize = true;
            this.chkDocuViaj.Location = new System.Drawing.Point(24, 343);
            this.chkDocuViaj.Name = "chkDocuViaj";
            this.chkDocuViaj.Size = new System.Drawing.Size(126, 17);
            this.chkDocuViaj.TabIndex = 16;
            this.chkDocuViaj.Text = "Documentos de viaje";
            this.chkDocuViaj.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(19, 319);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(131, 13);
            this.label36.TabIndex = 15;
            this.label36.Text = "Documentos presentados:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(19, 406);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(122, 13);
            this.label35.TabIndex = 19;
            this.label35.Text = "Decision sobre el visado";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(16, 302);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(136, 13);
            this.label34.TabIndex = 14;
            this.label34.Text = "Expediente gestionado por:";
            // 
            // chkOtro
            // 
            this.chkOtro.AutoSize = true;
            this.chkOtro.Location = new System.Drawing.Point(24, 242);
            this.chkOtro.Name = "chkOtro";
            this.chkOtro.Size = new System.Drawing.Size(51, 17);
            this.chkOtro.TabIndex = 12;
            this.chkOtro.Text = "Otros";
            this.chkOtro.UseVisualStyleBackColor = true;
            // 
            // chkFrontera
            // 
            this.chkFrontera.AutoSize = true;
            this.chkFrontera.Location = new System.Drawing.Point(32, 211);
            this.chkFrontera.Name = "chkFrontera";
            this.chkFrontera.Size = new System.Drawing.Size(65, 17);
            this.chkFrontera.TabIndex = 11;
            this.chkFrontera.Text = "Frontera";
            this.chkFrontera.UseVisualStyleBackColor = true;
            // 
            // chkIntermediario
            // 
            this.chkIntermediario.AutoSize = true;
            this.chkIntermediario.Location = new System.Drawing.Point(32, 190);
            this.chkIntermediario.Name = "chkIntermediario";
            this.chkIntermediario.Size = new System.Drawing.Size(134, 17);
            this.chkIntermediario.TabIndex = 10;
            this.chkIntermediario.Text = "Intermediario comercial";
            this.chkIntermediario.UseVisualStyleBackColor = true;
            // 
            // chkProveerdor
            // 
            this.chkProveerdor.AutoSize = true;
            this.chkProveerdor.Location = new System.Drawing.Point(32, 168);
            this.chkProveerdor.Name = "chkProveerdor";
            this.chkProveerdor.Size = new System.Drawing.Size(134, 17);
            this.chkProveerdor.TabIndex = 9;
            this.chkProveerdor.Text = "Proveedor de servicios";
            this.chkProveerdor.UseVisualStyleBackColor = true;
            // 
            // chkCcs
            // 
            this.chkCcs.AutoSize = true;
            this.chkCcs.Location = new System.Drawing.Point(32, 145);
            this.chkCcs.Name = "chkCcs";
            this.chkCcs.Size = new System.Drawing.Size(47, 17);
            this.chkCcs.TabIndex = 8;
            this.chkCcs.Text = "CCS";
            this.chkCcs.UseVisualStyleBackColor = true;
            // 
            // chkEmbajada
            // 
            this.chkEmbajada.AutoSize = true;
            this.chkEmbajada.Location = new System.Drawing.Point(32, 122);
            this.chkEmbajada.Name = "chkEmbajada";
            this.chkEmbajada.Size = new System.Drawing.Size(130, 17);
            this.chkEmbajada.TabIndex = 7;
            this.chkEmbajada.Text = "Embajada/consultado";
            this.chkEmbajada.UseVisualStyleBackColor = true;
            // 
            // txtNumSolicitud
            // 
            this.txtNumSolicitud.Location = new System.Drawing.Point(148, 68);
            this.txtNumSolicitud.Name = "txtNumSolicitud";
            this.txtNumSolicitud.Size = new System.Drawing.Size(100, 20);
            this.txtNumSolicitud.TabIndex = 5;
            this.txtNumSolicitud.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumSolicitud_KeyPress);
            // 
            // txtFSolicitud
            // 
            this.txtFSolicitud.Location = new System.Drawing.Point(148, 37);
            this.txtFSolicitud.Name = "txtFSolicitud";
            this.txtFSolicitud.Size = new System.Drawing.Size(100, 20);
            this.txtFSolicitud.TabIndex = 3;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(13, 246);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(0, 13);
            this.label33.TabIndex = 13;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(13, 68);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(131, 13);
            this.label32.TabIndex = 4;
            this.label32.Text = "Numero de la Solicitud en:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(13, 98);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(121, 13);
            this.label31.TabIndex = 6;
            this.label31.Text = "Solicitud presentada en:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(13, 37);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(109, 13);
            this.label30.TabIndex = 2;
            this.label30.Text = "Fecha de la Solicitud:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(127, 7);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(212, 13);
            this.label29.TabIndex = 1;
            this.label29.Text = "PARTE RESERVA LA ADMINISTRACION ";
            // 
            // chkMujer
            // 
            this.chkMujer.AutoSize = true;
            this.chkMujer.Location = new System.Drawing.Point(133, 35);
            this.chkMujer.Name = "chkMujer";
            this.chkMujer.Size = new System.Drawing.Size(52, 17);
            this.chkMujer.TabIndex = 5;
            this.chkMujer.Text = "Mujer";
            this.chkMujer.UseVisualStyleBackColor = true;
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(20, 19);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(34, 13);
            this.Label7.TabIndex = 3;
            this.Label7.Text = "Sexo:";
            // 
            // chkVaron
            // 
            this.chkVaron.AutoSize = true;
            this.chkVaron.Location = new System.Drawing.Point(133, 13);
            this.chkVaron.Name = "chkVaron";
            this.chkVaron.Size = new System.Drawing.Size(57, 17);
            this.chkVaron.TabIndex = 4;
            this.chkVaron.Text = "Varon ";
            this.chkVaron.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.chkMujer);
            this.panel2.Controls.Add(this.Label7);
            this.panel2.Controls.Add(this.chkVaron);
            this.panel2.Controls.Add(this.chkotros);
            this.panel2.Controls.Add(this.chkviuda);
            this.panel2.Controls.Add(this.chkdivorsiado);
            this.panel2.Controls.Add(this.chkseparado);
            this.panel2.Controls.Add(this.chkcasado);
            this.panel2.Controls.Add(this.chksoltero);
            this.panel2.Controls.Add(this.Label8);
            this.panel2.Location = new System.Drawing.Point(252, 313);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(591, 55);
            this.panel2.TabIndex = 75;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.chkDocViaje);
            this.panel3.Controls.Add(this.chkPasaEspecial);
            this.panel3.Controls.Add(this.chkPasaOficial);
            this.panel3.Controls.Add(this.chkPasaServicio);
            this.panel3.Controls.Add(this.chkPasaDiplo);
            this.panel3.Controls.Add(this.chkPasaOrdin);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Location = new System.Drawing.Point(319, 378);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(466, 82);
            this.panel3.TabIndex = 76;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtCalles);
            this.panel4.Controls.Add(this.label24);
            this.panel4.Controls.Add(this.txtCorreo);
            this.panel4.Controls.Add(this.label26);
            this.panel4.Controls.Add(this.label28);
            this.panel4.Controls.Add(this.txtNumTelefono);
            this.panel4.Controls.Add(this.txtResidpaisdis);
            this.panel4.Controls.Add(this.label27);
            this.panel4.Location = new System.Drawing.Point(25, 488);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(433, 127);
            this.panel4.TabIndex = 77;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApplication2.Properties.Resources.t;
            this.pictureBox1.Location = new System.Drawing.Point(1084, 32);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(113, 87);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 64;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.txtExpedidopor);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtValidohast);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txtFeExpedicion);
            this.Controls.Add(this.txtNumDocuViaje);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtNumDocumentoIden);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtDomicilio);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.p1);
            this.Controls.Add(this.datapFechaNa);
            this.Controls.Add(this.btnSalir);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.txtPaisNacim);
            this.Controls.Add(this.txtApellidosNaci);
            this.Controls.Add(this.txtLugarNacim);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.dgvRes);
            this.Controls.Add(this.txtNacionalid);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.txtNombres);
            this.Controls.Add(this.txtApellido);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRes)).EndInit();
            this.p1.ResumeLayout(false);
            this.p1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReserva)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Label Label10;
        private System.Windows.Forms.DataGridView dgvRes;
        internal System.Windows.Forms.TextBox txtNacionalid;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.TextBox txtNombres;
        internal System.Windows.Forms.TextBox txtApellido;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.TextBox txtLugarNacim;
        internal System.Windows.Forms.TextBox txtApellidosNaci;
        internal System.Windows.Forms.TextBox txtPaisNacim;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DateTimePicker datapFechaNa;
        private System.Windows.Forms.CheckBox chksoltero;
        private System.Windows.Forms.CheckBox chkcasado;
        private System.Windows.Forms.CheckBox chkseparado;
        private System.Windows.Forms.CheckBox chkdivorsiado;
        private System.Windows.Forms.CheckBox chkviuda;
        private System.Windows.Forms.CheckBox chkotros;
        private System.Windows.Forms.Panel p1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtNaTuMen;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtDirMenor;
        private System.Windows.Forms.TextBox txtNomMenor;
        private System.Windows.Forms.TextBox txtApMenor;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtDomicilio;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtNumDocumentoIden;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox chkPasaOrdin;
        private System.Windows.Forms.CheckBox chkPasaDiplo;
        private System.Windows.Forms.CheckBox chkPasaServicio;
        private System.Windows.Forms.CheckBox chkDocViaje;
        private System.Windows.Forms.CheckBox chkPasaEspecial;
        private System.Windows.Forms.CheckBox chkPasaOficial;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtNumDocuViaje;
        private System.Windows.Forms.TextBox txtFeExpedicion;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtValidohast;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtExpedidopor;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtCalles;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtResidpaisdis;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtNumTelefono;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chkExpedidoDe;
        private System.Windows.Forms.CheckBox chkDenegado;
        private System.Windows.Forms.CheckBox chkOtroDoc;
        private System.Windows.Forms.CheckBox chkSeguroMedico;
        private System.Windows.Forms.CheckBox chkMediosTrans;
        private System.Windows.Forms.CheckBox chkInvitacion;
        private System.Windows.Forms.CheckBox chkMediosSub;
        private System.Windows.Forms.CheckBox chkDocuViaj;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.CheckBox chkOtro;
        private System.Windows.Forms.CheckBox chkFrontera;
        private System.Windows.Forms.CheckBox chkIntermediario;
        private System.Windows.Forms.CheckBox chkProveerdor;
        private System.Windows.Forms.CheckBox chkCcs;
        private System.Windows.Forms.CheckBox chkEmbajada;
        private System.Windows.Forms.TextBox txtNumSolicitud;
        private System.Windows.Forms.TextBox txtFSolicitud;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.DataGridView dgvReserva;
        private System.Windows.Forms.CheckBox chkMujer;
        internal System.Windows.Forms.Label Label7;
        private System.Windows.Forms.CheckBox chkVaron;
        private System.Windows.Forms.Button btnSalirReserva;
        private System.Windows.Forms.Button btnModificaReserva;
        private System.Windows.Forms.Button btnGuardaReserva;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn NOMBRE;
        private System.Windows.Forms.DataGridViewTextBoxColumn APELLIDO;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn nacimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn FECHANACI;
        private System.Windows.Forms.DataGridViewTextBoxColumn NACIONALIDA;
        private System.Windows.Forms.DataGridViewTextBoxColumn sex;
        private System.Windows.Forms.DataGridViewTextBoxColumn ESTADCIVI;
        private System.Windows.Forms.DataGridViewTextBoxColumn pais;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
    }
}

