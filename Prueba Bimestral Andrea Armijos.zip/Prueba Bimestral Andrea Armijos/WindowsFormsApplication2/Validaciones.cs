﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication2
{
    class Validaciones
    {
        
        public static string validacorreo(string correo)
        {
            char[] del = { '@' };
            string[] email = correo.Split(del);
            if (email[0].Length > 1 && email[1].Length > 1)
            {
                return "Valido";
            }
            else
            {
                return "Invalido";
            }
        }
        }
    
}
