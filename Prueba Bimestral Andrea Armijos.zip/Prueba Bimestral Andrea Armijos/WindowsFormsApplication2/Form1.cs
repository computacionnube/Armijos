﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        int fil = 0;
        int filRe = 0;

        private void txtApellidoCo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }

        }

        private void txtNombres_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }

        }

        private void txtApellidos_KeyPress(object sender, KeyPressEventArgs e)
        {
            string p1=txtApellido.Text, p2=txtApellidosNaci.Text ;
            
            if (p1 == p2)
            {
                txtNombres.Enabled = true;

                txtNombres.Focus();

            }
            else
            {
                txtNombres.Enabled = false;
                MessageBox.Show("APELLIDOS INCORRECTOS");
                txtApellidosNaci.Focus();
            }
            
        }

        private void txtNacionalid_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }
        private void txtNumDocuViaje_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit  (letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }

        private void txtFeExpedicion_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }

        private void txtValidohast_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }

        private void txtExpedidopor_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }

        }

        private void txtCalles_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }

        private void txtResidpaisdis_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }

        private void txtNumTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }

        private void dgvRes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            fil = dgvRes.CurrentRow.Index;
            txtApellido.Text= dgvRes.Rows[fil].Cells[0].Value.ToString();
            txtApellidosNaci.Text= dgvRes.Rows[fil].Cells[1].Value.ToString();
            txtNombres.Text= dgvRes.Rows[fil].Cells[2].Value.ToString();
            datapFechaNa.Text= dgvRes.Rows[fil].Cells[3].Value.ToString();
            txtApMenor.Text= dgvRes.Rows[fil].Cells[4].Value.ToString();
            txtNomMenor.Text= dgvRes.Rows[fil].Cells[5].Value.ToString();
            txtDirMenor.Text= dgvRes.Rows[fil].Cells[6].Value.ToString();
            txtNaTuMen.Text= dgvRes.Rows[fil].Cells[7].Value.ToString();
            txtDomicilio.Text= dgvRes.Rows[fil].Cells[8].Value.ToString();
            txtLugarNacim.Text= dgvRes.Rows[fil].Cells[9].Value.ToString();
            txtPaisNacim.Text= dgvRes.Rows[fil].Cells[10].Value.ToString();
            txtNacionalid.Text= dgvRes.Rows[fil].Cells[11].Value.ToString();
            txtNumDocumentoIden.Text= dgvRes.Rows[fil].Cells[14].Value.ToString();
            txtNumDocuViaje.Text= dgvRes.Rows[fil].Cells[16].Value.ToString();
            txtFeExpedicion.Text= dgvRes.Rows[fil].Cells[17].Value.ToString();
            txtValidohast.Text= dgvRes.Rows[fil].Cells[18].Value.ToString();
            txtExpedidopor.Text= dgvRes.Rows[fil].Cells[19].Value.ToString();
            txtCalles.Text= dgvRes.Rows[fil].Cells[20].Value.ToString();
            txtCorreo.Text= dgvRes.Rows[fil].Cells[21].Value.ToString();
            txtResidpaisdis.Text= dgvRes.Rows[fil].Cells[22].Value.ToString();
            txtNumTelefono.Text= dgvRes.Rows[fil].Cells[23].Value.ToString();
  
        }
        public void presentar(int a)
        {
            dgvRes.Rows[fil].Cells[0].Value = txtApellido.Text;
            dgvRes.Rows[fil].Cells[1].Value = txtApellidosNaci.Text;
            dgvRes.Rows[fil].Cells[2].Value = txtNombres.Text;
            dgvRes.Rows[fil].Cells[3].Value = datapFechaNa.Text;
            dgvRes.Rows[fil].Cells[4].Value = txtApMenor.Text;
            dgvRes.Rows[fil].Cells[5].Value = txtNomMenor.Text;
            dgvRes.Rows[fil].Cells[6].Value = txtDirMenor.Text;
            dgvRes.Rows[fil].Cells[7].Value = txtNaTuMen.Text;
            dgvRes.Rows[fil].Cells[8].Value = txtDomicilio.Text;
            dgvRes.Rows[fil].Cells[9].Value = txtLugarNacim.Text;
            dgvRes.Rows[fil].Cells[10].Value = txtPaisNacim.Text;
            dgvRes.Rows[fil].Cells[11].Value = txtNacionalid.Text;
            dgvRes.Rows[fil].Cells[14].Value = txtNumDocumentoIden.Text;
            dgvRes.Rows[fil].Cells[16].Value = txtNumDocuViaje.Text;
            dgvRes.Rows[fil].Cells[17].Value = txtFeExpedicion.Text;
            dgvRes.Rows[fil].Cells[18].Value = txtValidohast.Text;
            dgvRes.Rows[fil].Cells[19].Value = txtExpedidopor.Text;
            dgvRes.Rows[fil].Cells[20].Value = txtCalles.Text;
            dgvRes.Rows[fil].Cells[21].Value = txtCorreo.Text;
            dgvRes.Rows[fil].Cells[22].Value = txtResidpaisdis.Text;
            dgvRes.Rows[fil].Cells[23].Value = txtNumTelefono.Text;
         
        }
        public void Modificar()
        {
            fil = dgvRes.CurrentRow.Index;
            dgvRes.Rows[fil].Cells[0].Value = txtApellido.Text;
            dgvRes.Rows[fil].Cells[1].Value = txtApellidosNaci.Text;
            dgvRes.Rows[fil].Cells[2].Value = txtNombres.Text;
            dgvRes.Rows[fil].Cells[3].Value = datapFechaNa.Text;
            dgvRes.Rows[fil].Cells[4].Value = txtApMenor.Text;
            dgvRes.Rows[fil].Cells[5].Value = txtNomMenor.Text;
            dgvRes.Rows[fil].Cells[6].Value = txtDirMenor.Text;
            dgvRes.Rows[fil].Cells[7].Value = txtNaTuMen.Text;
            dgvRes.Rows[fil].Cells[8].Value = txtDomicilio.Text;
            dgvRes.Rows[fil].Cells[9].Value = txtLugarNacim.Text;
            dgvRes.Rows[fil].Cells[10].Value = txtPaisNacim.Text;
            dgvRes.Rows[fil].Cells[11].Value = txtNacionalid.Text;
            dgvRes.Rows[fil].Cells[14].Value = txtNumDocumentoIden.Text;
            dgvRes.Rows[fil].Cells[16].Value = txtNumDocuViaje.Text;
            dgvRes.Rows[fil].Cells[17].Value = txtFeExpedicion.Text;
            dgvRes.Rows[fil].Cells[18].Value = txtValidohast.Text;
            dgvRes.Rows[fil].Cells[19].Value = txtExpedidopor.Text;
            dgvRes.Rows[fil].Cells[20].Value = txtCalles.Text;
            dgvRes.Rows[fil].Cells[21].Value = txtCorreo.Text;
            dgvRes.Rows[fil].Cells[22].Value = txtResidpaisdis.Text;
            dgvRes.Rows[fil].Cells[23].Value = txtNumTelefono.Text;

        }
        public void limpiar()
        {
            txtApellido.Text = "";
            txtApellidosNaci.Text = "";
            txtNombres.Text = "";
            datapFechaNa.Text = "";
            txtApMenor.Text = "";
            txtNomMenor.Text = "";
            txtDirMenor.Text = "";
            txtNaTuMen.Text = "";
            txtDomicilio.Text = "";
            txtLugarNacim.Text = "";
            txtPaisNacim.Text = "";
            txtNacionalid.Text = "";
            txtNumDocumentoIden.Text = "";
            txtNumDocuViaje.Text = "";
            txtFeExpedicion.Text = "";
            txtValidohast.Text= "";
            txtExpedidopor.Text= "";
            txtCalles.Text= "";
            txtCorreo.Text= "";
            txtResidpaisdis.Text= "";
            txtNumTelefono.Text= "";
            
          
            
        }
        
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Bisque;
          
            edadV();
            fil = dgvRes.Rows.Count - 1;
            //Para obtner el sexo
            if (chkVaron.Checked == true) { dgvRes.Rows[fil].Cells[9].Value = "Varon"; }
            else { if (chkMujer.Checked == true) { dgvRes.Rows[fil].Cells[9].Value = "Mujer"; } }
            //Para Estado CIvil
            if (chksoltero.Checked == true) { dgvRes.Rows[fil].Cells[10].Value = "Soltero/a"; }
            else { if (chkcasado.Checked == true) { dgvRes.Rows[fil].Cells[10].Value = "Casado/a"; } }
            if (chkseparado.Checked == true) { dgvRes.Rows[fil].Cells[10].Value = "Sepadaro/a"; }
            else { if (chkdivorsiado.Checked == true) { dgvRes.Rows[fil].Cells[10].Value = "Divorsiado/a"; } }
            if (chkviuda.Checked == true) { dgvRes.Rows[fil].Cells[10].Value = "Viudo/a"; }
            else { if (chkotros.Checked == true) { dgvRes.Rows[fil].Cells[10].Value = ""; } }

            
            //Para obtener el tipo de documento de viaje
            if (chkPasaOrdin.Checked == true) { dgvRes.Rows[fil].Cells[12].Value = "Pasaporte Ordinario"; }
            else { if (chkPasaDiplo .Checked == true) { dgvRes.Rows[fil].Cells[8].Value = "Pasaporte Diplomatico"; } }
            if (chkPasaServicio.Checked == true) { dgvRes.Rows[fil].Cells[8].Value = "Pasaporte de Servicio"; }
            else { if (chkPasaOficial.Checked == true) { dgvRes.Rows[fil].Cells[8].Value = "Pasaporte Oficial"; } }
            if (chkPasaEspecial.Checked == true) { dgvRes.Rows[fil].Cells[12].Value = "Pasaporte Especial"; }
            else { if (chkDocViaje.Checked == true) { dgvRes.Rows[fil].Cells[8].Value = "Otro Documento Viaje"; } }
            presentar(fil);
            limpiar();
            MessageBox.Show("Guardado Exitosamente", "Guardar", MessageBoxButtons.YesNo);
            }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            Modificar();

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

            DialogResult eli = MessageBox.Show("Desea Eliminar ?", "Eliminar", MessageBoxButtons.YesNoCancel);
            if (eli == DialogResult.Yes)
            {
                dgvRes.Rows.RemoveAt(fil);
                limpiar();
            }
            //dgvRes.Rows.Remove(dgvRes.Select());
           
        }
        private void btnSalir_Click(object sender, EventArgs e)
        {

            DialogResult r = MessageBox.Show("SEGURO DESEA SALIR.....", "SALIR APLICACION", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }


        public void edadV()
        {
            //Variables
            int d, m, a,edad;
            d = DateTime.Now.Day;
            m = DateTime.Now.Month;
            a = DateTime.Now.Year;

            if(d < datapFechaNa.Value.Day)
            {
                d += m;

                m -= m;
            }

            if (m < datapFechaNa.Value.Month)
            {
                m += a;

                a -= a;
            }

            edad = d - datapFechaNa.Value.Day;

            edad = m - datapFechaNa.Value.Month;

            edad = a - datapFechaNa.Value.Year;

            if (edad <= 17)
            {
                p1.Enabled = true;
                txtApMenor.Focus();
            }

            else
            {
                p1.Enabled = false;
            }
        }

        private void datapFechaNa_ValueChanged(object sender, EventArgs e)
        {
            edadV();
        }
        //PARTE RESERVA LA ADMINISTRACION 
        private void dgvReserva_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            filRe = dgvReserva.CurrentRow.Index;
            txtFSolicitud.Text = dgvReserva.Rows[filRe].Cells[0].Value.ToString();
            txtNumSolicitud.Text = dgvReserva.Rows[filRe].Cells[1].Value.ToString();
        }
        public void presentarRe(int a)
        {
            dgvReserva.Rows[filRe ].Cells[0].Value = txtFSolicitud.Text;
            dgvReserva.Rows[filRe].Cells[1].Value = txtNumSolicitud.Text;
            if (chkEmbajada.Checked == true) { dgvReserva.Rows[filRe].Cells[2].Value = "Embajada/consultado"; }
            else { if (chkCcs.Checked == true) { dgvReserva.Rows[filRe].Cells[2].Value = "CCS"; } }
            if (chkProveerdor.Checked == true) { dgvReserva.Rows[filRe].Cells[2].Value = "Proveedor de Servicios"; }
            else { if (chkIntermediario.Checked == true) { dgvReserva.Rows[filRe].Cells[2].Value = "Intermediario Comercial"; } }
            if (chkFrontera.Checked == true) { dgvReserva.Rows[filRe].Cells[2].Value = "Frontera"; }
            //Para expedientes gestionado ,documentos presentados 
            if (chkDocuViaj.Checked == true) { dgvReserva.Rows[filRe].Cells[3].Value = "Documentos de Viaje"; }
            else { if (chkMediosSub.Checked == true) { dgvReserva.Rows[filRe].Cells[3].Value = "Medios de Subsistencia"; } }
            if (chkInvitacion.Checked == true) { dgvReserva.Rows[filRe].Cells[3].Value = "Invitacion"; }
            else { if (chkMediosTrans.Checked == true) { dgvReserva.Rows[filRe].Cells[3].Value = "Medios de Transporte"; } }
            if (chkSeguroMedico.Checked == true) { dgvReserva.Rows[filRe].Cells[3].Value = "Seguro Medico de viaje"; }
            else { if (chkOtroDoc.Checked == true) { dgvReserva.Rows[filRe].Cells[3].Value = "Otro"; } }

            //Decision sobre el visado
            if (chkDenegado.Checked == true) { dgvReserva.Rows[filRe].Cells[4].Value = "Denegado"; }
            else { if (chkExpedidoDe.Checked == true) { dgvReserva.Rows[filRe].Cells[4].Value = "Expedido"; } }
        }
        public void ModificarRe()
        {
            filRe = dgvRes.CurrentRow.Index;
            dgvReserva.Rows[filRe].Cells[0].Value = txtFSolicitud.Text;
            dgvReserva.Rows[filRe].Cells[1].Value = txtNumSolicitud.Text;
            
       


        }
        public void limpiarRe()
        {
            txtFSolicitud.Text = "";
            txtNumSolicitud.Text = "";

        }
 
        private void btnGuardaReserva_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Azure;
            filRe= dgvReserva.Rows.Count - 1;
            presentarRe(filRe);
            limpiarRe();

            MessageBox.Show("Guardado Exitosamente", "Guardar", MessageBoxButtons.YesNo);
            if (txtFSolicitud.TextLength<0&&txtNumSolicitud.TextLength<0)
            {
                
            }
        }

        private void btnModificaReserva_Click(object sender, EventArgs e)
        {
            filRe=dgvReserva.Rows.Count - 1;
            dgvReserva.Rows[filRe].Cells[0].Value = txtFSolicitud.Text;
            dgvReserva.Rows[filRe].Cells[1].Value = txtNumSolicitud.Text;
        }

        private void btnEliminaReserva_Click(object sender, EventArgs e)
        {
            DialogResult elina= MessageBox.Show("Desea Eliminar ?", "Eliminar", MessageBoxButtons.YesNoCancel);
            if (elina == DialogResult.Yes)
            {
                dgvReserva.Rows.RemoveAt(filRe);
                limpiar();
            }

        }

        private void btnSalirReserva_Click(object sender, EventArgs e)
        {

            DialogResult r = MessageBox.Show("SEGURO DESEA SALIR.....", "SALIR APLICACION", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            if (r == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        //correo
        string mail;


        private void txtCorreo_Leave(object sender, EventArgs e)
        {
            if (txtCorreo.Text.Contains("@"))
            {
                mail = Validaciones.validacorreo(txtCorreo.Text);

            }
            else
            {
                MessageBox.Show("Error. Correo Incorrecto");
                txtCorreo.Clear();
                txtCorreo.Focus();
            }
        }

        private void txtNumSolicitud_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit (letra) && letra != 13 && letra != 8 && letra != 32)
            {
                e.Handled = true;
            }
        }
    }
}
