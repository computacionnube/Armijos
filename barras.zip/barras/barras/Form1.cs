﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace barras
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void reloj_Tick(object sender, EventArgs e)
        {
            pbprogresbaranima.Value = pbprogresbaranima.Value + 1;
            lblprogresbar.Text = Convert.ToString(pbprogresbaranima.Value);
            if (pbprogresbaranima.Value == 100)
            {

                reloj.Stop();
                MessageBox.Show("tiempo terminado");
                pbprogresbaranima.Value = 0;
            }
        }

        private void btninicio_Click(object sender, EventArgs e)
        {
            reloj.Start();
        }

        private void tbdesc_Scroll(object sender, EventArgs e)
        {
            lbltaclback.Text = tbdesc.Value.ToString();
            double total = double.Parse(txtcosto.Text) - double.Parse(txtcosto.Text) * tbdesc.Value / 100;
            lbltot.Text = "Total a cobrar: " + total;
        }

        private void tsboton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ejercicio 1");
        }

        private void tstboton2_Click(object sender, EventArgs e)
        {
            if (tstboton2.Checked == false)
            {
                tstboton2.Checked = true;
                MessageBox.Show("Boton Presionado");

            }
            else
            {
                tstboton2.Checked = false;
                MessageBox.Show("Boton Sin  Presionado");
            }
        }

        private void tstxt1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char tecla = e.KeyChar;
            if(tecla == 13)
            {
                if (tstxt1.Text == "Activate")
                {
                    tstboton3.Visible = true;
                }
            }
        }
    }
}