﻿namespace barras
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pbprogresbaranima = new System.Windows.Forms.ProgressBar();
            this.reloj = new System.Windows.Forms.Timer(this.components);
            this.btninicio = new System.Windows.Forms.Button();
            this.lblprogresbar = new System.Windows.Forms.Label();
            this.tbdesc = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.txtcosto = new System.Windows.Forms.TextBox();
            this.lbltot = new System.Windows.Forms.Label();
            this.lbltaclback = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsboton1 = new System.Windows.Forms.ToolStripButton();
            this.tstboton2 = new System.Windows.Forms.ToolStripButton();
            this.tstboton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tscb1 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.tslbl1 = new System.Windows.Forms.ToolStripLabel();
            this.tstxt1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.tbdesc)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbprogresbaranima
            // 
            this.pbprogresbaranima.BackColor = System.Drawing.Color.Green;
            this.pbprogresbaranima.Location = new System.Drawing.Point(84, 35);
            this.pbprogresbaranima.Name = "pbprogresbaranima";
            this.pbprogresbaranima.Size = new System.Drawing.Size(285, 23);
            this.pbprogresbaranima.TabIndex = 0;
            // 
            // reloj
            // 
            this.reloj.Tick += new System.EventHandler(this.reloj_Tick);
            // 
            // btninicio
            // 
            this.btninicio.Location = new System.Drawing.Point(3, 35);
            this.btninicio.Name = "btninicio";
            this.btninicio.Size = new System.Drawing.Size(75, 23);
            this.btninicio.TabIndex = 1;
            this.btninicio.Text = "INICIO";
            this.btninicio.UseVisualStyleBackColor = true;
            this.btninicio.Click += new System.EventHandler(this.btninicio_Click);
            // 
            // lblprogresbar
            // 
            this.lblprogresbar.AutoSize = true;
            this.lblprogresbar.Location = new System.Drawing.Point(376, 44);
            this.lblprogresbar.Name = "lblprogresbar";
            this.lblprogresbar.Size = new System.Drawing.Size(13, 13);
            this.lblprogresbar.TabIndex = 2;
            this.lblprogresbar.Text = "0";
            // 
            // tbdesc
            // 
            this.tbdesc.BackColor = System.Drawing.Color.Lime;
            this.tbdesc.LargeChange = 10;
            this.tbdesc.Location = new System.Drawing.Point(120, 77);
            this.tbdesc.Maximum = 100;
            this.tbdesc.Name = "tbdesc";
            this.tbdesc.Size = new System.Drawing.Size(312, 45);
            this.tbdesc.SmallChange = 2;
            this.tbdesc.TabIndex = 3;
            this.tbdesc.TickFrequency = 5;
            this.tbdesc.Value = 10;
            this.tbdesc.Scroll += new System.EventHandler(this.tbdesc_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(58, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Costo";
            // 
            // txtcosto
            // 
            this.txtcosto.Location = new System.Drawing.Point(98, 154);
            this.txtcosto.Name = "txtcosto";
            this.txtcosto.Size = new System.Drawing.Size(100, 20);
            this.txtcosto.TabIndex = 5;
            // 
            // lbltot
            // 
            this.lbltot.AutoSize = true;
            this.lbltot.Location = new System.Drawing.Point(58, 201);
            this.lbltot.Name = "lbltot";
            this.lbltot.Size = new System.Drawing.Size(79, 13);
            this.lbltot.TabIndex = 6;
            this.lbltot.Text = "Total a cobrar: ";
            // 
            // lbltaclback
            // 
            this.lbltaclback.AutoSize = true;
            this.lbltaclback.Location = new System.Drawing.Point(379, 94);
            this.lbltaclback.Name = "lbltaclback";
            this.lbltaclback.Size = new System.Drawing.Size(19, 13);
            this.lbltaclback.TabIndex = 7;
            this.lbltaclback.Text = "10";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsboton1,
            this.tstboton2,
            this.tstboton3,
            this.toolStripSeparator1,
            this.tscb1,
            this.toolStripButton4,
            this.tslbl1,
            this.tstxt1,
            this.toolStripDropDownButton1,
            this.toolStripSplitButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(513, 25);
            this.toolStrip1.TabIndex = 8;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsboton1
            // 
            this.tsboton1.Checked = true;
            this.tsboton1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsboton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsboton1.Image = ((System.Drawing.Image)(resources.GetObject("tsboton1.Image")));
            this.tsboton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsboton1.Name = "tsboton1";
            this.tsboton1.Size = new System.Drawing.Size(23, 22);
            this.tsboton1.Text = "Ejercicio 1";
            this.tsboton1.Click += new System.EventHandler(this.tsboton1_Click);
            // 
            // tstboton2
            // 
            this.tstboton2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tstboton2.BackgroundImage")));
            this.tstboton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tstboton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tstboton2.Image = ((System.Drawing.Image)(resources.GetObject("tstboton2.Image")));
            this.tstboton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tstboton2.Name = "tstboton2";
            this.tstboton2.Size = new System.Drawing.Size(64, 22);
            this.tstboton2.Text = "Ejercicio 2";
            this.tstboton2.Click += new System.EventHandler(this.tstboton2_Click);
            // 
            // tstboton3
            // 
            this.tstboton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tstboton3.Image = ((System.Drawing.Image)(resources.GetObject("tstboton3.Image")));
            this.tstboton3.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.tstboton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tstboton3.Name = "tstboton3";
            this.tstboton3.Size = new System.Drawing.Size(23, 22);
            this.tstboton3.Text = "Ejercicio 3";
            this.tstboton3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tstboton3.Visible = false;
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // tscb1
            // 
            this.tscb1.Items.AddRange(new object[] {
            "Ejercicio 4",
            "Ejercicio 5",
            "Ejercicio 6"});
            this.tscb1.Name = "tscb1";
            this.tscb1.Size = new System.Drawing.Size(121, 25);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "toolStripButton4";
            // 
            // tslbl1
            // 
            this.tslbl1.Name = "tslbl1";
            this.tslbl1.Size = new System.Drawing.Size(82, 22);
            this.tslbl1.Text = "Programación";
            // 
            // tstxt1
            // 
            this.tstxt1.Name = "tstxt1";
            this.tstxt1.Size = new System.Drawing.Size(100, 25);
            this.tstxt1.TextBoxTextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tstxt1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tstxt1_KeyPress);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 22);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(127, 22);
            this.toolStripMenuItem1.Text = "Ejercicio 7";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(127, 22);
            this.toolStripMenuItem2.Text = "Ejrcicio 8";
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.toolStripSplitButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripSplitButton1.Image")));
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 22);
            this.toolStripSplitButton1.Text = "toolStripSplitButton1";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(133, 22);
            this.toolStripMenuItem3.Text = "Ejercicio 9";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(133, 22);
            this.toolStripMenuItem4.Text = "Ejercicio 10";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 243);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lbltaclback);
            this.Controls.Add(this.lbltot);
            this.Controls.Add(this.txtcosto);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbdesc);
            this.Controls.Add(this.lblprogresbar);
            this.Controls.Add(this.btninicio);
            this.Controls.Add(this.pbprogresbaranima);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.tbdesc)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar pbprogresbaranima;
        private System.Windows.Forms.Timer reloj;
        private System.Windows.Forms.Button btninicio;
        private System.Windows.Forms.Label lblprogresbar;
        private System.Windows.Forms.TrackBar tbdesc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtcosto;
        private System.Windows.Forms.Label lbltot;
        private System.Windows.Forms.Label lbltaclback;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsboton1;
        private System.Windows.Forms.ToolStripButton tstboton2;
        private System.Windows.Forms.ToolStripButton tstboton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripComboBox tscb1;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripLabel tslbl1;
        private System.Windows.Forms.ToolStripTextBox tstxt1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
    }
}

