﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TabControl
{
    //Trabajar con estructuras
    struct Agenda
        {
        string cedula, nombre, direccion,telefono,correo;
        string primaria, bachillerato, titulo, superior, titulosuperior;
        public Agenda(string ced, string nom, string dirc, string tel, string cor, string pri, string bach, string tit, string sup, string titulosup)//constructor
            {
                cedula = ced;
                nombre = nom;
                direccion = dirc;
                telefono = tel;
                correo = cor;
                primaria = pri;
                bachillerato = bach;
                titulo = tit;
                superior = sup;
                titulosuperior = titulosup;
            }
       public void setcedul(string ced)
        {
            cedula = ced;
        }
        public string getcedula()
       {
           return cedula;
       }
        public void setnombr(string nom)
        {
            nombre = nom;
        }
        public string getnom()
        {
            return nombre;
        }
        public void setdirecc(string direc)
        {
            direccion = direc;
        }
        public string getdirec()
        {
            return direccion;
        }

        public void settele(string tel)
        {
            telefono = tel;
        }
        public string gettel()
        {
            return telefono;
        }

        public void setcorr(string corr)
        {
            correo = corr;
        }
        public string getcorr()
        {
            return correo;
        }
        //---------------------------ingreso b --------------
        public void setpri(string pri)
        {
            primaria = pri;
        }
        public string getpri()
        {
            return primaria;
        }

        public void setbach(string bach)
        {
            bachillerato = bach;
        }
        public string getbach()
        {
            return bachillerato;
        }

        public void settit(string tit)
        {
            titulo = tit;
        }
        public string gettit()
        {
            return titulo;
        }

        public void setsup(string sup)
        {
            superior = sup;
        }
        public string getsup()
        {
            return superior;
        }

        public void settitulosup(string titulosup)
        {
            titulosuperior = titulosup;
        }
        public string gettitulosup()
        {
            return titulosuperior;
        }
       
        }
    public partial class Form1 : Form
    {
        int indice=0;//permite moverse entre las fichas
        Agenda[] contactos = new Agenda[100];
        int pos = 0;
        int pe = 0;
        string estado = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tsl2.Text += DateTime.Now.ToString();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Desarrollador");
        }

        private void tsl1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Datos personales");
        }

        private void tcdatos_SelectedIndexChanged(object sender, EventArgs e)
        {
            tcdatos.SelectTab(indice);         
        }

        private void ingresoBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            indice = 1;
            tcdatos.SelectTab(indice);
            deshabilita();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            indice = 1;
            tcdatos.SelectTab(indice);
        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            indice = 0;
            tcdatos.SelectTab(indice);
            habilita();
        }

        private void ingresoBToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            indice = 2;
            tcdatos.SelectTab(indice);
            deshabilita();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            indice = 0;
            tcdatos.SelectTab(indice);
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            indice = 2;
            tcdatos.SelectTab(indice);
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            indice = 1;
            tcdatos.SelectTab(indice);//nos ubicamos en la ficha correspondiente
            estado = "N";
            limpiar();
        }

        private void btnGuarda_Click(object sender, EventArgs e)
        {
            if (estado =="N")
            {
                llenaestructura(pos);
                pos++;
                lstAgenda.Items.Add(txtcedula.Text + "," + txtnombres.Text + "," + txtdireccion.Text + "," + txtelefono.Text + "," + txtcorreo.Text+ "," +txtprimaria.Text+ "," +txtbachillerato.Text+ "," +txttitulo.Text+ "," +txtsuperior.Text+ "," +txttitulosuperior.Text);
                estado= "";

            }//fin if
            if (estado=="E")
            {
                llenaestructura(pe);//los datos viejos se reemplazan con los nuevos
                lstAgenda.Items.Insert(pe, txtcedula.Text + "," + txtnombres.Text + "," + txtdireccion.Text + "," + txtelefono.Text + "," + txtcorreo.Text + "," + txtprimaria.Text + "," + txtbachillerato.Text + "," + txttitulo.Text + "," + txtsuperior.Text + "," + txttitulosuperior.Text);//para que inserte el registro
                estado = "";
                lstAgenda.Items.RemoveAt(pe+1);
            }
            indice=2;
            tcdatos.SelectTab(indice);
        }
        private void llenaestructura(int i)
        {
            contactos[i].setcedul(txtcedula.Text);
            contactos[i].setnombr(txtnombres.Text);
            contactos[i].setdirecc(txtdireccion.Text);
            contactos[i].setcorr(txtcorreo.Text);
            contactos[i].settele(txtelefono.Text);

            contactos[i].setpri(txtprimaria.Text);
            contactos[i].setbach(txtbachillerato.Text);
            contactos[i].settit(txttitulo.Text);
            contactos[i].setsup(txtsuperior.Text);
            contactos[i].settitulosup(txttitulosuperior.Text);
        }

        private void btnregresar_Click(object sender, EventArgs e)
        {
            indice = 0; //regreasa al inicio
            tcdatos.SelectTab(indice);
        }

        private void txtcedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }     
        }

        private void txtnombres_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void txtelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsDigit (letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten numeros", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;               
            }
        }

        //ingreso b

        private void txtbachillerato_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void txttitulo_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void txtsuperior_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }

        private void txttitulosuperior_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {
                MessageBox.Show("Solo se permiten letras", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                e.Handled = true;
            }
        }


        private void btnEdita_Click(object sender, EventArgs e)
        {
            indice = 1;
            tcdatos.SelectTab(indice);
            estado = "E";
        }

        private void lstAgenda_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstAgenda.SelectedIndex>=0)
            {
                pe = lstAgenda.SelectedIndex;//recoger el elemento seleccionado
                txtcedula.Text = contactos[pe].getcedula();//traigo la cedula
                txtnombres.Text = contactos[pe].getnom();
                txtdireccion.Text = contactos[pe].getdirec();
                txtelefono.Text = contactos[pe].gettel();
                txtcorreo.Text = contactos[pe].getcorr();

                txtprimaria.Text = contactos[pe].getpri();
                txtbachillerato.Text = contactos[pe].getbach();
                txttitulo.Text = contactos[pe].gettit();
                txtsuperior.Text = contactos[pe].getsup();
                txttitulosuperior.Text = contactos[pe].gettitulosup();               
            }
        }
        private void btnSale_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void limpiar()
        {
            foreach (Control txt in this.p2.Controls)//el forech es como el for
            {
                if (txt is TextBox) txt.Text = "";
            }
        }
        private void habilita()
        {
            p1.Enabled = true;
            p2.Enabled = true;
            p3.Enabled = true;
        }
        private void deshabilita()
        {
            p1.Enabled = false;
            p2.Enabled = false;
            p3.Enabled = false;
        }

        private void btnguardar_Click(object sender, EventArgs e)
        {
            if (btnguardar.Enabled == true)
            {
                btnregresar.Enabled = true;
            }
        }

        private void btncancelar_Click(object sender, EventArgs e)
        {         
                indice = 0; 
                tcdatos.SelectTab(indice);       
        }

       



       
       

       

      
    }
}
