﻿namespace TabControl
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.datosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inicioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresoAToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.ingresoBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresoBToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsl1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsl2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsp1 = new System.Windows.Forms.ToolStripProgressBar();
            this.tsm1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tls4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.tcdatos = new System.Windows.Forms.TabControl();
            this.tp1 = new System.Windows.Forms.TabPage();
            this.btnSale = new System.Windows.Forms.Button();
            this.p1 = new System.Windows.Forms.Panel();
            this.btnEdita = new System.Windows.Forms.Button();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.lstAgenda = new System.Windows.Forms.ListBox();
            this.tp2 = new System.Windows.Forms.TabPage();
            this.p2 = new System.Windows.Forms.Panel();
            this.btncancelar = new System.Windows.Forms.Button();
            this.btnGuarda = new System.Windows.Forms.Button();
            this.txtcorreo = new System.Windows.Forms.TextBox();
            this.txtelefono = new System.Windows.Forms.TextBox();
            this.txtdireccion = new System.Windows.Forms.TextBox();
            this.txtnombres = new System.Windows.Forms.TextBox();
            this.txtcedula = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tp3 = new System.Windows.Forms.TabPage();
            this.p3 = new System.Windows.Forms.Panel();
            this.btnregresar = new System.Windows.Forms.Button();
            this.btnguardar = new System.Windows.Forms.Button();
            this.txtprimaria = new System.Windows.Forms.TextBox();
            this.txtbachillerato = new System.Windows.Forms.TextBox();
            this.txttitulo = new System.Windows.Forms.TextBox();
            this.txtsuperior = new System.Windows.Forms.TextBox();
            this.txttitulosuperior = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.tcdatos.SuspendLayout();
            this.tp1.SuspendLayout();
            this.p1.SuspendLayout();
            this.tp2.SuspendLayout();
            this.p2.SuspendLayout();
            this.tp3.SuspendLayout();
            this.p3.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.datosToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(837, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // datosToolStripMenuItem
            // 
            this.datosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inicioToolStripMenuItem,
            this.ingresoAToolStripMenuItem,
            this.ingresoBToolStripMenuItem,
            this.ingresoBToolStripMenuItem1});
            this.datosToolStripMenuItem.Name = "datosToolStripMenuItem";
            this.datosToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.datosToolStripMenuItem.Text = "Datos";
            // 
            // inicioToolStripMenuItem
            // 
            this.inicioToolStripMenuItem.Name = "inicioToolStripMenuItem";
            this.inicioToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.inicioToolStripMenuItem.Text = "Inicio";
            this.inicioToolStripMenuItem.Click += new System.EventHandler(this.inicioToolStripMenuItem_Click);
            // 
            // ingresoAToolStripMenuItem
            // 
            this.ingresoAToolStripMenuItem.Name = "ingresoAToolStripMenuItem";
            this.ingresoAToolStripMenuItem.Size = new System.Drawing.Size(121, 6);
            // 
            // ingresoBToolStripMenuItem
            // 
            this.ingresoBToolStripMenuItem.Name = "ingresoBToolStripMenuItem";
            this.ingresoBToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.ingresoBToolStripMenuItem.Text = "Ingreso A";
            this.ingresoBToolStripMenuItem.Click += new System.EventHandler(this.ingresoBToolStripMenuItem_Click);
            // 
            // ingresoBToolStripMenuItem1
            // 
            this.ingresoBToolStripMenuItem1.Name = "ingresoBToolStripMenuItem1";
            this.ingresoBToolStripMenuItem1.Size = new System.Drawing.Size(124, 22);
            this.ingresoBToolStripMenuItem1.Text = "Ingreso B";
            this.ingresoBToolStripMenuItem1.Click += new System.EventHandler(this.ingresoBToolStripMenuItem1_Click);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(41, 20);
            this.salirToolStripMenuItem.Text = "Salir";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsl1,
            this.tsl2,
            this.tsp1,
            this.tsm1,
            this.tls4});
            this.statusStrip1.Location = new System.Drawing.Point(0, 270);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(837, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsl1
            // 
            this.tsl1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.tsl1.BorderStyle = System.Windows.Forms.Border3DStyle.Raised;
            this.tsl1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.tsl1.Image = ((System.Drawing.Image)(resources.GetObject("tsl1.Image")));
            this.tsl1.Name = "tsl1";
            this.tsl1.Size = new System.Drawing.Size(64, 17);
            this.tsl1.Text = "Agenda";
            this.tsl1.Click += new System.EventHandler(this.tsl1_Click);
            // 
            // tsl2
            // 
            this.tsl2.BackColor = System.Drawing.Color.DarkRed;
            this.tsl2.ForeColor = System.Drawing.Color.Black;
            this.tsl2.Name = "tsl2";
            this.tsl2.Size = new System.Drawing.Size(41, 17);
            this.tsl2.Text = "Fecha:";
            // 
            // tsp1
            // 
            this.tsp1.Name = "tsp1";
            this.tsp1.Size = new System.Drawing.Size(100, 16);
            this.tsp1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            // 
            // tsm1
            // 
            this.tsm1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsm1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3});
            this.tsm1.Image = ((System.Drawing.Image)(resources.GetObject("tsm1.Image")));
            this.tsm1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsm1.Name = "tsm1";
            this.tsm1.Size = new System.Drawing.Size(29, 20);
            this.tsm1.Text = "toolStripDropDownButton1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(179, 22);
            this.toolStripMenuItem1.Text = "Stefany";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(179, 22);
            this.toolStripMenuItem2.Text = "Analisis de Sistemas";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(179, 22);
            this.toolStripMenuItem3.Text = "Cuarto Ciclo";
            // 
            // tls4
            // 
            this.tls4.Name = "tls4";
            this.tls4.Size = new System.Drawing.Size(118, 17);
            this.tls4.Text = "toolStripStatusLabel1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripComboBox1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(837, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton2.Text = "toolStripButton2";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "toolStripButton3";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 25);
            // 
            // tcdatos
            // 
            this.tcdatos.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tcdatos.Controls.Add(this.tp1);
            this.tcdatos.Controls.Add(this.tp2);
            this.tcdatos.Controls.Add(this.tp3);
            this.tcdatos.Location = new System.Drawing.Point(24, 75);
            this.tcdatos.Name = "tcdatos";
            this.tcdatos.SelectedIndex = 0;
            this.tcdatos.Size = new System.Drawing.Size(801, 192);
            this.tcdatos.TabIndex = 3;
            this.tcdatos.SelectedIndexChanged += new System.EventHandler(this.tcdatos_SelectedIndexChanged);
            // 
            // tp1
            // 
            this.tp1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tp1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.tp1.Controls.Add(this.btnSale);
            this.tp1.Controls.Add(this.p1);
            this.tp1.Controls.Add(this.lstAgenda);
            this.tp1.Location = new System.Drawing.Point(4, 25);
            this.tp1.Name = "tp1";
            this.tp1.Padding = new System.Windows.Forms.Padding(3);
            this.tp1.Size = new System.Drawing.Size(793, 163);
            this.tp1.TabIndex = 0;
            this.tp1.Text = "Inicio";
            // 
            // btnSale
            // 
            this.btnSale.Location = new System.Drawing.Point(701, 79);
            this.btnSale.Name = "btnSale";
            this.btnSale.Size = new System.Drawing.Size(75, 23);
            this.btnSale.TabIndex = 2;
            this.btnSale.Text = "Salir";
            this.btnSale.UseVisualStyleBackColor = true;
            this.btnSale.Click += new System.EventHandler(this.btnSale_Click);
            // 
            // p1
            // 
            this.p1.Controls.Add(this.btnEdita);
            this.p1.Controls.Add(this.btnNuevo);
            this.p1.Location = new System.Drawing.Point(697, 6);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(86, 67);
            this.p1.TabIndex = 1;
            // 
            // btnEdita
            // 
            this.btnEdita.Location = new System.Drawing.Point(4, 34);
            this.btnEdita.Name = "btnEdita";
            this.btnEdita.Size = new System.Drawing.Size(75, 23);
            this.btnEdita.TabIndex = 1;
            this.btnEdita.Text = "Editar";
            this.btnEdita.UseVisualStyleBackColor = true;
            this.btnEdita.Click += new System.EventHandler(this.btnEdita_Click);
            // 
            // btnNuevo
            // 
            this.btnNuevo.Location = new System.Drawing.Point(4, 5);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(75, 23);
            this.btnNuevo.TabIndex = 0;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // lstAgenda
            // 
            this.lstAgenda.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.lstAgenda.FormattingEnabled = true;
            this.lstAgenda.Location = new System.Drawing.Point(6, 6);
            this.lstAgenda.Name = "lstAgenda";
            this.lstAgenda.Size = new System.Drawing.Size(685, 147);
            this.lstAgenda.TabIndex = 0;
            this.lstAgenda.SelectedIndexChanged += new System.EventHandler(this.lstAgenda_SelectedIndexChanged);
            // 
            // tp2
            // 
            this.tp2.BackColor = System.Drawing.Color.Lime;
            this.tp2.Controls.Add(this.p2);
            this.tp2.Location = new System.Drawing.Point(4, 25);
            this.tp2.Name = "tp2";
            this.tp2.Padding = new System.Windows.Forms.Padding(3);
            this.tp2.Size = new System.Drawing.Size(793, 163);
            this.tp2.TabIndex = 1;
            this.tp2.Text = "Ingreso A";
            // 
            // p2
            // 
            this.p2.BackColor = System.Drawing.Color.Yellow;
            this.p2.Controls.Add(this.btncancelar);
            this.p2.Controls.Add(this.btnGuarda);
            this.p2.Controls.Add(this.txtcorreo);
            this.p2.Controls.Add(this.txtelefono);
            this.p2.Controls.Add(this.txtdireccion);
            this.p2.Controls.Add(this.txtnombres);
            this.p2.Controls.Add(this.txtcedula);
            this.p2.Controls.Add(this.label5);
            this.p2.Controls.Add(this.label4);
            this.p2.Controls.Add(this.label3);
            this.p2.Controls.Add(this.label2);
            this.p2.Controls.Add(this.label1);
            this.p2.Location = new System.Drawing.Point(40, 6);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(348, 140);
            this.p2.TabIndex = 0;
            // 
            // btncancelar
            // 
            this.btncancelar.Location = new System.Drawing.Point(251, 86);
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(75, 23);
            this.btncancelar.TabIndex = 10;
            this.btncancelar.Text = "Cancelar";
            this.btncancelar.UseVisualStyleBackColor = true;
            this.btncancelar.Click += new System.EventHandler(this.btncancelar_Click);
            // 
            // btnGuarda
            // 
            this.btnGuarda.Location = new System.Drawing.Point(251, 50);
            this.btnGuarda.Name = "btnGuarda";
            this.btnGuarda.Size = new System.Drawing.Size(75, 23);
            this.btnGuarda.TabIndex = 9;
            this.btnGuarda.Text = "Guardar";
            this.btnGuarda.UseVisualStyleBackColor = true;
            this.btnGuarda.Click += new System.EventHandler(this.btnGuarda_Click);
            // 
            // txtcorreo
            // 
            this.txtcorreo.Location = new System.Drawing.Point(92, 112);
            this.txtcorreo.Name = "txtcorreo";
            this.txtcorreo.Size = new System.Drawing.Size(142, 20);
            this.txtcorreo.TabIndex = 1;
            // 
            // txtelefono
            // 
            this.txtelefono.Location = new System.Drawing.Point(92, 86);
            this.txtelefono.Name = "txtelefono";
            this.txtelefono.Size = new System.Drawing.Size(142, 20);
            this.txtelefono.TabIndex = 8;
            this.txtelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtelefono_KeyPress);
            // 
            // txtdireccion
            // 
            this.txtdireccion.Location = new System.Drawing.Point(92, 60);
            this.txtdireccion.Name = "txtdireccion";
            this.txtdireccion.Size = new System.Drawing.Size(142, 20);
            this.txtdireccion.TabIndex = 7;
            // 
            // txtnombres
            // 
            this.txtnombres.Location = new System.Drawing.Point(92, 34);
            this.txtnombres.Name = "txtnombres";
            this.txtnombres.Size = new System.Drawing.Size(142, 20);
            this.txtnombres.TabIndex = 6;
            this.txtnombres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnombres_KeyPress);
            // 
            // txtcedula
            // 
            this.txtcedula.Location = new System.Drawing.Point(92, 8);
            this.txtcedula.Name = "txtcedula";
            this.txtcedula.Size = new System.Drawing.Size(142, 20);
            this.txtcedula.TabIndex = 5;
            this.txtcedula.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcedula_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "CORREO:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "TEEFONO: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 60);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "DIRECCION:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "NOMBRES:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "CEDULA: ";
            // 
            // tp3
            // 
            this.tp3.BackColor = System.Drawing.Color.Green;
            this.tp3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tp3.Controls.Add(this.p3);
            this.tp3.Location = new System.Drawing.Point(4, 25);
            this.tp3.Name = "tp3";
            this.tp3.Padding = new System.Windows.Forms.Padding(3);
            this.tp3.Size = new System.Drawing.Size(793, 163);
            this.tp3.TabIndex = 2;
            this.tp3.Text = "Ingreso B";
            // 
            // p3
            // 
            this.p3.Controls.Add(this.btnregresar);
            this.p3.Controls.Add(this.btnguardar);
            this.p3.Controls.Add(this.txtprimaria);
            this.p3.Controls.Add(this.txtbachillerato);
            this.p3.Controls.Add(this.txttitulo);
            this.p3.Controls.Add(this.txtsuperior);
            this.p3.Controls.Add(this.txttitulosuperior);
            this.p3.Controls.Add(this.label10);
            this.p3.Controls.Add(this.label9);
            this.p3.Controls.Add(this.label8);
            this.p3.Controls.Add(this.label7);
            this.p3.Controls.Add(this.label6);
            this.p3.Location = new System.Drawing.Point(6, 6);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(399, 149);
            this.p3.TabIndex = 0;
            // 
            // btnregresar
            // 
            this.btnregresar.Enabled = false;
            this.btnregresar.Location = new System.Drawing.Point(292, 84);
            this.btnregresar.Name = "btnregresar";
            this.btnregresar.Size = new System.Drawing.Size(75, 23);
            this.btnregresar.TabIndex = 11;
            this.btnregresar.Text = "Regresar";
            this.btnregresar.UseVisualStyleBackColor = true;
            this.btnregresar.Click += new System.EventHandler(this.btnregresar_Click);
            // 
            // btnguardar
            // 
            this.btnguardar.Location = new System.Drawing.Point(292, 45);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(75, 23);
            this.btnguardar.TabIndex = 10;
            this.btnguardar.Text = "Guardar";
            this.btnguardar.UseVisualStyleBackColor = true;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // txtprimaria
            // 
            this.txtprimaria.Location = new System.Drawing.Point(111, 3);
            this.txtprimaria.Name = "txtprimaria";
            this.txtprimaria.Size = new System.Drawing.Size(152, 20);
            this.txtprimaria.TabIndex = 9;
            // 
            // txtbachillerato
            // 
            this.txtbachillerato.Location = new System.Drawing.Point(111, 29);
            this.txtbachillerato.Name = "txtbachillerato";
            this.txtbachillerato.Size = new System.Drawing.Size(152, 20);
            this.txtbachillerato.TabIndex = 8;
            this.txtbachillerato.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbachillerato_KeyPress);
            // 
            // txttitulo
            // 
            this.txttitulo.Location = new System.Drawing.Point(111, 55);
            this.txttitulo.Name = "txttitulo";
            this.txttitulo.Size = new System.Drawing.Size(152, 20);
            this.txttitulo.TabIndex = 7;
            this.txttitulo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txttitulo_KeyPress);
            // 
            // txtsuperior
            // 
            this.txtsuperior.Location = new System.Drawing.Point(111, 81);
            this.txtsuperior.Name = "txtsuperior";
            this.txtsuperior.Size = new System.Drawing.Size(152, 20);
            this.txtsuperior.TabIndex = 6;
            this.txtsuperior.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsuperior_KeyPress);
            // 
            // txttitulosuperior
            // 
            this.txttitulosuperior.Location = new System.Drawing.Point(111, 109);
            this.txttitulosuperior.Name = "txttitulosuperior";
            this.txttitulosuperior.Size = new System.Drawing.Size(152, 20);
            this.txttitulosuperior.TabIndex = 5;
            this.txttitulosuperior.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txttitulosuperior_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(28, 112);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Titulo: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 84);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 13);
            this.label9.TabIndex = 3;
            this.label9.Text = "Superior:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Titulo:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 1;
            this.label7.Text = "Bachillerato:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Primaria: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 292);
            this.Controls.Add(this.tcdatos);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tcdatos.ResumeLayout(false);
            this.tp1.ResumeLayout(false);
            this.p1.ResumeLayout(false);
            this.tp2.ResumeLayout(false);
            this.p2.ResumeLayout(false);
            this.p2.PerformLayout();
            this.tp3.ResumeLayout(false);
            this.p3.ResumeLayout(false);
            this.p3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem datosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inicioToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator ingresoAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresoBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresoBToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsl1;
        private System.Windows.Forms.ToolStripStatusLabel tsl2;
        private System.Windows.Forms.ToolStripProgressBar tsp1;
        private System.Windows.Forms.ToolStripDropDownButton tsm1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripStatusLabel tls4;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.TabControl tcdatos;
        private System.Windows.Forms.TabPage tp1;
        private System.Windows.Forms.TabPage tp2;
        private System.Windows.Forms.TabPage tp3;
        private System.Windows.Forms.Button btnSale;
        private System.Windows.Forms.Panel p1;
        private System.Windows.Forms.Button btnEdita;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.ListBox lstAgenda;
        private System.Windows.Forms.Panel p2;
        private System.Windows.Forms.Button btncancelar;
        private System.Windows.Forms.Button btnGuarda;
        private System.Windows.Forms.TextBox txtcorreo;
        private System.Windows.Forms.TextBox txtelefono;
        private System.Windows.Forms.TextBox txtdireccion;
        private System.Windows.Forms.TextBox txtnombres;
        private System.Windows.Forms.TextBox txtcedula;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel p3;
        private System.Windows.Forms.TextBox txtprimaria;
        private System.Windows.Forms.TextBox txtbachillerato;
        private System.Windows.Forms.TextBox txttitulo;
        private System.Windows.Forms.TextBox txtsuperior;
        private System.Windows.Forms.TextBox txttitulosuperior;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnregresar;
        private System.Windows.Forms.Button btnguardar;
    }
}

