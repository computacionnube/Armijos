﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace registrodeestudiantes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string nombres, apellidos, direccion, telefono, nacionalidad, documento, correo, año, mes, dia, pais, provincia,medicacion, canton, parroquia;
        string unidad_educativa, carrera, ciclo, estado_civil, primaria, secundaria, titulo_secundario, tipo_sangre, trabajo;
        string edad, estatura, raza, peso, finalizacion_estudios_secundarios, titulo_superior, viveen_Loja, enfermedad_catastrofica, discapacidad, emergencia;
        int pos;
        int i = 1;

        private void btnguardar_Click(object sender, EventArgs e)
        {
            nombres = textnombres.Text;
            apellidos = textapellidos.Text;
            direccion = textdireccion.Text;
            telefono = texttelefono.Text;
            nacionalidad = textnacionalidad.Text;
            estado_civil = cboestado_civil.Text;
            documento = textdocumento.Text;
            correo = textcorreo.Text;
            año = textaño.Text;
            mes = cbomes.Text;
            dia = cbodia.Text;
            pais = textpais.Text;
            provincia = cbodocumento.Text;
            canton = cbocanton.Text;
            parroquia = cboparroquia.Text;
            unidad_educativa = textunidad_educativa.Text;
            carrera = cbocarrera.Text;
            ciclo = cbociclo.Text;
            primaria = textestudios_primarios.Text;
            secundaria = textestudios_secundarios.Text;
            titulo_secundario = textestudios_secundarios.Text;
            tipo_sangre = cbotipo_sangre.Text;
            edad = textedad.Text;
            estatura = textedad.Text;
            raza = cboraza.Text;
            peso = textedad.Text;
            finalizacion_estudios_secundarios = cbofinalizacionestudios_secundarios.Text;
            titulo_superior = texttitulo_superior.Text;
            viveen_Loja = textviveen_loja.Text;
            enfermedad_catastrofica = textenfermedad.Text;
            discapacidad = cbodiscapacidad.Text;
            emergencia = texttelefonos_emergencia.Text;
            trabajo = cbotrabajo.Text;
            medicacion = cbomedicacion.Text;
            dataGridView1.Rows.Add(documento, nombres, apellidos, correo, telefono,direccion, nacionalidad, año, mes, dia);
            dataGridView2.Rows.Add(pais, provincia,canton,parroquia);
            dataGridView3.Rows.Add(estado_civil, primaria, secundaria, titulo_secundario, finalizacion_estudios_secundarios, unidad_educativa, ciclo, carrera, titulo_superior,trabajo);
            dataGridView4.Rows.Add(tipo_sangre,edad,raza,peso,estatura);
            dataGridView5.Rows.Add(viveen_Loja,enfermedad_catastrofica, medicacion, discapacidad,emergencia);
        }

        private void btnmodificar_Click(object sender, EventArgs e)
        {

        }

        private void cbotelefono_SelectedIndexChanged(object sender, EventArgs e)
        {
            string telefono;
            if (btnguardar.Enabled == true)
            {
                if (cbotelefono.SelectedIndex == 0)
                {
                    telefono = texttelefono.Text;
                    texttelefono.Enabled = true;
                }
                else
                {
                    if (cbotelefono.SelectedIndex == 1)
                    {
                        telefono = texttelefono.Text;
                        texttelefono.Enabled = true;
                    }
                }
            }
        }

       
      
    }
}
