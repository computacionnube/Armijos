﻿namespace registrodeestudiantes
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textnombres = new System.Windows.Forms.TextBox();
            this.textapellidos = new System.Windows.Forms.TextBox();
            this.textdireccion = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.textcorreo = new System.Windows.Forms.TextBox();
            this.textdocumento = new System.Windows.Forms.TextBox();
            this.textnacionalidad = new System.Windows.Forms.TextBox();
            this.cbotelefono = new System.Windows.Forms.ComboBox();
            this.cbodia = new System.Windows.Forms.ComboBox();
            this.cbomes = new System.Windows.Forms.ComboBox();
            this.cbodocumento = new System.Windows.Forms.ComboBox();
            this.texttelefono = new System.Windows.Forms.TextBox();
            this.textpais = new System.Windows.Forms.TextBox();
            this.textaño = new System.Windows.Forms.TextBox();
            this.cbocanton = new System.Windows.Forms.ComboBox();
            this.cboparroquia = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.texttitulo = new System.Windows.Forms.TextBox();
            this.textestudios_secundarios = new System.Windows.Forms.TextBox();
            this.textestudios_primarios = new System.Windows.Forms.TextBox();
            this.cboestado_civil = new System.Windows.Forms.ComboBox();
            this.cbocarrera = new System.Windows.Forms.ComboBox();
            this.textunidad_educativa = new System.Windows.Forms.TextBox();
            this.cbociclo = new System.Windows.Forms.ComboBox();
            this.cbotipo_sangre = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textedad = new System.Windows.Forms.TextBox();
            this.textestatura = new System.Windows.Forms.TextBox();
            this.textpeso = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cbofinalizacionestudios_secundarios = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.cbosuperior = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.texttitulo_superior = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cboviveenloja = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textviveen_loja = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.cbotrabajo = new System.Windows.Forms.ComboBox();
            this.label36 = new System.Windows.Forms.Label();
            this.cboraza = new System.Windows.Forms.ComboBox();
            this.label37 = new System.Windows.Forms.Label();
            this.cboenfermedad = new System.Windows.Forms.ComboBox();
            this.textenfermedad = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.cbomedicacion = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.cbodiscapacidad = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.texttelefonos_emergencia = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Documento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombres = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Apellidos = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Correo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direccion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nacionalidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Año = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Pais = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Provincia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Canton = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Paroquia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Edad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btneliminar = new System.Windows.Forms.Button();
            this.btnactualizar = new System.Windows.Forms.Button();
            this.btnmodificar = new System.Windows.Forms.Button();
            this.btnguardar = new System.Windows.Forms.Button();
            this.cboprovincia = new System.Windows.Forms.ComboBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombres:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Apellidos:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Telefono:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Direccion:";
            // 
            // textnombres
            // 
            this.textnombres.Location = new System.Drawing.Point(70, 59);
            this.textnombres.Name = "textnombres";
            this.textnombres.Size = new System.Drawing.Size(182, 20);
            this.textnombres.TabIndex = 7;
            // 
            // textapellidos
            // 
            this.textapellidos.Location = new System.Drawing.Point(71, 22);
            this.textapellidos.Name = "textapellidos";
            this.textapellidos.Size = new System.Drawing.Size(182, 20);
            this.textapellidos.TabIndex = 8;
            // 
            // textdireccion
            // 
            this.textdireccion.Location = new System.Drawing.Point(70, 96);
            this.textdireccion.Name = "textdireccion";
            this.textdireccion.Size = new System.Drawing.Size(182, 20);
            this.textdireccion.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 283);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nacionalidad:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 198);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Documento:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(130, 369);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(54, 13);
            this.label31.TabIndex = 64;
            this.label31.Text = "Provincia:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(12, 369);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(30, 13);
            this.label30.TabIndex = 63;
            this.label30.Text = "Pais:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(12, 350);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(108, 13);
            this.label29.TabIndex = 62;
            this.label29.Text = "Lugar de Nacimiento:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(263, 330);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(26, 13);
            this.label28.TabIndex = 61;
            this.label28.Text = "Dia:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(112, 330);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(30, 13);
            this.label27.TabIndex = 60;
            this.label27.Text = "Mes:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(12, 330);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(29, 13);
            this.label26.TabIndex = 59;
            this.label26.Text = "Año:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(13, 306);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(111, 13);
            this.label25.TabIndex = 58;
            this.label25.Text = "Fecha de Nacimiento:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 253);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 57;
            this.label10.Text = "Correo:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(183, 403);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(55, 13);
            this.label33.TabIndex = 66;
            this.label33.Text = "Parroquia:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(12, 403);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(44, 13);
            this.label32.TabIndex = 65;
            this.label32.Text = "Canton:";
            // 
            // textcorreo
            // 
            this.textcorreo.Location = new System.Drawing.Point(70, 250);
            this.textcorreo.Name = "textcorreo";
            this.textcorreo.Size = new System.Drawing.Size(182, 20);
            this.textcorreo.TabIndex = 75;
            // 
            // textdocumento
            // 
            this.textdocumento.Enabled = false;
            this.textdocumento.Location = new System.Drawing.Point(83, 220);
            this.textdocumento.Name = "textdocumento";
            this.textdocumento.Size = new System.Drawing.Size(169, 20);
            this.textdocumento.TabIndex = 73;
            // 
            // textnacionalidad
            // 
            this.textnacionalidad.Location = new System.Drawing.Point(83, 280);
            this.textnacionalidad.Name = "textnacionalidad";
            this.textnacionalidad.Size = new System.Drawing.Size(169, 20);
            this.textnacionalidad.TabIndex = 72;
            // 
            // cbotelefono
            // 
            this.cbotelefono.FormattingEnabled = true;
            this.cbotelefono.Items.AddRange(new object[] {
            "Convencional",
            "Fijo"});
            this.cbotelefono.Location = new System.Drawing.Point(70, 130);
            this.cbotelefono.Name = "cbotelefono";
            this.cbotelefono.Size = new System.Drawing.Size(182, 21);
            this.cbotelefono.TabIndex = 70;
            this.cbotelefono.Text = "Seleccione";
            this.cbotelefono.SelectedIndexChanged += new System.EventHandler(this.cbotelefono_SelectedIndexChanged);
            // 
            // cbodia
            // 
            this.cbodia.FormattingEnabled = true;
            this.cbodia.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "",
            ""});
            this.cbodia.Location = new System.Drawing.Point(295, 327);
            this.cbodia.Name = "cbodia";
            this.cbodia.Size = new System.Drawing.Size(52, 21);
            this.cbodia.TabIndex = 79;
            // 
            // cbomes
            // 
            this.cbomes.FormattingEnabled = true;
            this.cbomes.Items.AddRange(new object[] {
            "Enero",
            "Febrero",
            "Marzo",
            "Abril",
            "Mayo",
            "Junio",
            "Julio",
            "Agosto",
            "Septiembre",
            "Octubre",
            "Noviembre",
            "Diciembre"});
            this.cbomes.Location = new System.Drawing.Point(148, 327);
            this.cbomes.Name = "cbomes";
            this.cbomes.Size = new System.Drawing.Size(104, 21);
            this.cbomes.TabIndex = 78;
            this.cbomes.Text = "Seleccione";
            // 
            // cbodocumento
            // 
            this.cbodocumento.FormattingEnabled = true;
            this.cbodocumento.Items.AddRange(new object[] {
            "Nacional",
            "Extranjero"});
            this.cbodocumento.Location = new System.Drawing.Point(83, 193);
            this.cbodocumento.Name = "cbodocumento";
            this.cbodocumento.Size = new System.Drawing.Size(169, 21);
            this.cbodocumento.TabIndex = 80;
            this.cbodocumento.Text = "Seleccione";
            // 
            // texttelefono
            // 
            this.texttelefono.Enabled = false;
            this.texttelefono.Location = new System.Drawing.Point(69, 158);
            this.texttelefono.Name = "texttelefono";
            this.texttelefono.Size = new System.Drawing.Size(183, 20);
            this.texttelefono.TabIndex = 81;
            // 
            // textpais
            // 
            this.textpais.Location = new System.Drawing.Point(42, 366);
            this.textpais.Name = "textpais";
            this.textpais.Size = new System.Drawing.Size(82, 20);
            this.textpais.TabIndex = 82;
            // 
            // textaño
            // 
            this.textaño.Location = new System.Drawing.Point(42, 327);
            this.textaño.Name = "textaño";
            this.textaño.Size = new System.Drawing.Size(60, 20);
            this.textaño.TabIndex = 83;
            // 
            // cbocanton
            // 
            this.cbocanton.FormattingEnabled = true;
            this.cbocanton.Items.AddRange(new object[] {
            "Calvas",
            "Catamayo",
            "Celica",
            "Chaguarpamba",
            "Espindola",
            "Loja",
            "Macara",
            "Olmedo",
            "Paltas",
            "Pindal",
            "Puyango",
            "Quilanga",
            "Saraguro",
            "Sozoranga",
            "Zapotillo",
            ""});
            this.cbocanton.Location = new System.Drawing.Point(62, 400);
            this.cbocanton.Name = "cbocanton";
            this.cbocanton.Size = new System.Drawing.Size(115, 21);
            this.cbocanton.TabIndex = 85;
            // 
            // cboparroquia
            // 
            this.cboparroquia.FormattingEnabled = true;
            this.cboparroquia.Items.AddRange(new object[] {
            "EL Sagrario",
            "EL Valle",
            "Sucre",
            "San Sebastian",
            "Punzara",
            "Carigan",
            "San Lucas",
            "El Cisne",
            "Vilcabamba",
            "Malacatos",
            "Chuquiribamba",
            "Chantaco",
            "Jimbilla",
            "Gualel",
            "YANGANA",
            "QUINARA",
            "TAQUIL",
            "SAN PEDRO DE VILCABAMBA",
            "SANTIAGO"});
            this.cboparroquia.Location = new System.Drawing.Point(244, 400);
            this.cboparroquia.Name = "cboparroquia";
            this.cboparroquia.Size = new System.Drawing.Size(172, 21);
            this.cboparroquia.TabIndex = 97;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(270, 253);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(83, 13);
            this.label18.TabIndex = 94;
            this.label18.Text = "Tipo de Sangre:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(270, 227);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 13);
            this.label17.TabIndex = 93;
            this.label17.Text = "Titulo:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(270, 165);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(95, 13);
            this.label14.TabIndex = 92;
            this.label14.Text = "Estudios Primarios:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(270, 198);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(112, 13);
            this.label13.TabIndex = 91;
            this.label13.Text = "Estudios Secundarios:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(270, 99);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 13);
            this.label12.TabIndex = 90;
            this.label12.Text = "Ciclo:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(270, 62);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 13);
            this.label11.TabIndex = 89;
            this.label11.Text = "Carrera:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(270, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 13);
            this.label9.TabIndex = 88;
            this.label9.Text = "Unidad Educativa:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(270, 138);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 13);
            this.label15.TabIndex = 87;
            this.label15.Text = "Estado Civil:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(353, 330);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 86;
            this.label16.Text = "Edad:";
            // 
            // texttitulo
            // 
            this.texttitulo.Location = new System.Drawing.Point(318, 224);
            this.texttitulo.Name = "texttitulo";
            this.texttitulo.Size = new System.Drawing.Size(218, 20);
            this.texttitulo.TabIndex = 104;
            // 
            // textestudios_secundarios
            // 
            this.textestudios_secundarios.Location = new System.Drawing.Point(391, 188);
            this.textestudios_secundarios.Name = "textestudios_secundarios";
            this.textestudios_secundarios.Size = new System.Drawing.Size(145, 20);
            this.textestudios_secundarios.TabIndex = 103;
            // 
            // textestudios_primarios
            // 
            this.textestudios_primarios.Location = new System.Drawing.Point(371, 162);
            this.textestudios_primarios.Name = "textestudios_primarios";
            this.textestudios_primarios.Size = new System.Drawing.Size(165, 20);
            this.textestudios_primarios.TabIndex = 102;
            // 
            // cboestado_civil
            // 
            this.cboestado_civil.FormattingEnabled = true;
            this.cboestado_civil.Items.AddRange(new object[] {
            "Casado/a",
            "Soltero/a",
            "Viudo/a",
            "Divorciado/a"});
            this.cboestado_civil.Location = new System.Drawing.Point(344, 135);
            this.cboestado_civil.Name = "cboestado_civil";
            this.cboestado_civil.Size = new System.Drawing.Size(192, 21);
            this.cboestado_civil.TabIndex = 101;
            this.cboestado_civil.Text = "Seleccione";
            // 
            // cbocarrera
            // 
            this.cbocarrera.FormattingEnabled = true;
            this.cbocarrera.Items.AddRange(new object[] {
            "Analisis de Sistemas",
            "Contabilid computarizada",
            "Diseño Grafico",
            "Industria de Alimentos",
            "Mecanica Industrial",
            "Redes y Telecomunicaciones"});
            this.cbocarrera.Location = new System.Drawing.Point(318, 59);
            this.cbocarrera.Name = "cbocarrera";
            this.cbocarrera.Size = new System.Drawing.Size(218, 21);
            this.cbocarrera.TabIndex = 100;
            this.cbocarrera.Text = "Seleccione";
            // 
            // textunidad_educativa
            // 
            this.textunidad_educativa.Location = new System.Drawing.Point(371, 22);
            this.textunidad_educativa.Name = "textunidad_educativa";
            this.textunidad_educativa.Size = new System.Drawing.Size(165, 20);
            this.textunidad_educativa.TabIndex = 99;
            // 
            // cbociclo
            // 
            this.cbociclo.FormattingEnabled = true;
            this.cbociclo.Items.AddRange(new object[] {
            "PRIMER CICLO",
            "SEGUNDO CICLO",
            "TERCER CICLO",
            "CUARTO CICLO",
            "QUINTO CICLO",
            "SEXTO CICLO"});
            this.cbociclo.Location = new System.Drawing.Point(318, 95);
            this.cbociclo.Name = "cbociclo";
            this.cbociclo.Size = new System.Drawing.Size(218, 21);
            this.cbociclo.TabIndex = 98;
            this.cbociclo.Text = "Seleccione";
            // 
            // cbotipo_sangre
            // 
            this.cbotipo_sangre.FormattingEnabled = true;
            this.cbotipo_sangre.Items.AddRange(new object[] {
            "A RH +",
            "A RH -",
            "B RH +",
            "B RH -",
            "AB RH +",
            "AB RH -",
            "O RH +",
            "O RH -"});
            this.cbotipo_sangre.Location = new System.Drawing.Point(359, 250);
            this.cbotipo_sangre.Name = "cbotipo_sangre";
            this.cbotipo_sangre.Size = new System.Drawing.Size(177, 21);
            this.cbotipo_sangre.TabIndex = 105;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(270, 283);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 13);
            this.label19.TabIndex = 107;
            this.label19.Text = "Estatura:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(411, 283);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(34, 13);
            this.label20.TabIndex = 106;
            this.label20.Text = "Peso:";
            // 
            // textedad
            // 
            this.textedad.Location = new System.Drawing.Point(391, 327);
            this.textedad.Name = "textedad";
            this.textedad.Size = new System.Drawing.Size(60, 20);
            this.textedad.TabIndex = 108;
            // 
            // textestatura
            // 
            this.textestatura.Location = new System.Drawing.Point(325, 280);
            this.textestatura.Name = "textestatura";
            this.textestatura.Size = new System.Drawing.Size(79, 20);
            this.textestatura.TabIndex = 109;
            // 
            // textpeso
            // 
            this.textpeso.Location = new System.Drawing.Point(442, 280);
            this.textpeso.Name = "textpeso";
            this.textpeso.Size = new System.Drawing.Size(94, 20);
            this.textpeso.TabIndex = 110;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(542, 9);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(220, 13);
            this.label21.TabIndex = 111;
            this.label21.Text = "En que año termino sus estudios secundarios";
            // 
            // cbofinalizacionestudios_secundarios
            // 
            this.cbofinalizacionestudios_secundarios.FormattingEnabled = true;
            this.cbofinalizacionestudios_secundarios.Items.AddRange(new object[] {
            "Recientemente",
            "El año pasado",
            "Hace mas de dos años"});
            this.cbofinalizacionestudios_secundarios.Location = new System.Drawing.Point(545, 22);
            this.cbofinalizacionestudios_secundarios.Name = "cbofinalizacionestudios_secundarios";
            this.cbofinalizacionestudios_secundarios.Size = new System.Drawing.Size(249, 21);
            this.cbofinalizacionestudios_secundarios.TabIndex = 112;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(545, 46);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(196, 13);
            this.label22.TabIndex = 113;
            this.label22.Text = "Tiene algun titulo de estudios superiores";
            // 
            // cbosuperior
            // 
            this.cbosuperior.FormattingEnabled = true;
            this.cbosuperior.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbosuperior.Location = new System.Drawing.Point(551, 62);
            this.cbosuperior.Name = "cbosuperior";
            this.cbosuperior.Size = new System.Drawing.Size(114, 21);
            this.cbosuperior.TabIndex = 114;
            this.cbosuperior.Text = "Seleccione";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(672, 66);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(28, 13);
            this.label23.TabIndex = 115;
            this.label23.Text = "Cual";
            // 
            // texttitulo_superior
            // 
            this.texttitulo_superior.Location = new System.Drawing.Point(697, 63);
            this.texttitulo_superior.Name = "texttitulo_superior";
            this.texttitulo_superior.Size = new System.Drawing.Size(113, 20);
            this.texttitulo_superior.TabIndex = 116;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(548, 83);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(96, 13);
            this.label24.TabIndex = 117;
            this.label24.Text = "Vive Fuera de Loja";
            // 
            // cboviveenloja
            // 
            this.cboviveenloja.FormattingEnabled = true;
            this.cboviveenloja.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cboviveenloja.Location = new System.Drawing.Point(548, 96);
            this.cboviveenloja.Name = "cboviveenloja";
            this.cboviveenloja.Size = new System.Drawing.Size(114, 21);
            this.cboviveenloja.TabIndex = 118;
            this.cboviveenloja.Text = "Seleccione";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(672, 99);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(39, 13);
            this.label34.TabIndex = 119;
            this.label34.Text = "Donde";
            // 
            // textviveen_loja
            // 
            this.textviveen_loja.Location = new System.Drawing.Point(715, 95);
            this.textviveen_loja.Name = "textviveen_loja";
            this.textviveen_loja.Size = new System.Drawing.Size(95, 20);
            this.textviveen_loja.TabIndex = 120;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(548, 120);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(102, 13);
            this.label35.TabIndex = 121;
            this.label35.Text = "Tiene algun Trabajo";
            // 
            // cbotrabajo
            // 
            this.cbotrabajo.FormattingEnabled = true;
            this.cbotrabajo.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbotrabajo.Location = new System.Drawing.Point(551, 136);
            this.cbotrabajo.Name = "cbotrabajo";
            this.cbotrabajo.Size = new System.Drawing.Size(111, 21);
            this.cbotrabajo.TabIndex = 122;
            this.cbotrabajo.Text = "Seleccione";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(457, 330);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(32, 13);
            this.label36.TabIndex = 123;
            this.label36.Text = "Raza";
            // 
            // cboraza
            // 
            this.cboraza.FormattingEnabled = true;
            this.cboraza.Items.AddRange(new object[] {
            "Mestizo",
            "Blanco",
            "Afroamericano",
            "Asiatico",
            "Montuvio"});
            this.cboraza.Location = new System.Drawing.Point(495, 327);
            this.cboraza.Name = "cboraza";
            this.cboraza.Size = new System.Drawing.Size(90, 21);
            this.cboraza.TabIndex = 124;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(548, 168);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(130, 13);
            this.label37.TabIndex = 125;
            this.label37.Text = "Tiene Alguna Enfermedad";
            // 
            // cboenfermedad
            // 
            this.cboenfermedad.FormattingEnabled = true;
            this.cboenfermedad.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cboenfermedad.Location = new System.Drawing.Point(548, 184);
            this.cboenfermedad.Name = "cboenfermedad";
            this.cboenfermedad.Size = new System.Drawing.Size(114, 21);
            this.cboenfermedad.TabIndex = 126;
            this.cboenfermedad.Text = "Seleccione";
            // 
            // textenfermedad
            // 
            this.textenfermedad.Location = new System.Drawing.Point(548, 224);
            this.textenfermedad.Name = "textenfermedad";
            this.textenfermedad.Size = new System.Drawing.Size(152, 20);
            this.textenfermedad.TabIndex = 127;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(548, 208);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(28, 13);
            this.label38.TabIndex = 128;
            this.label38.Text = "Cual";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(548, 258);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(138, 13);
            this.label39.TabIndex = 129;
            this.label39.Text = "Recibe Tratamiento Medico";
            // 
            // cbomedicacion
            // 
            this.cbomedicacion.FormattingEnabled = true;
            this.cbomedicacion.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbomedicacion.Location = new System.Drawing.Point(548, 280);
            this.cbomedicacion.Name = "cbomedicacion";
            this.cbomedicacion.Size = new System.Drawing.Size(114, 21);
            this.cbomedicacion.TabIndex = 130;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(711, 169);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(114, 13);
            this.label40.TabIndex = 131;
            this.label40.Text = "Practica algun deporte";
            // 
            // cbodiscapacidad
            // 
            this.cbodiscapacidad.FormattingEnabled = true;
            this.cbodiscapacidad.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cbodiscapacidad.Location = new System.Drawing.Point(831, 166);
            this.cbodiscapacidad.Name = "cbodiscapacidad";
            this.cbodiscapacidad.Size = new System.Drawing.Size(111, 21);
            this.cbodiscapacidad.TabIndex = 132;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(747, 248);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(28, 13);
            this.label41.TabIndex = 133;
            this.label41.Text = "Tipo";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Fisica",
            "Intelectual"});
            this.comboBox3.Location = new System.Drawing.Point(781, 245);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(114, 21);
            this.comboBox3.TabIndex = 134;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(764, 220);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(128, 13);
            this.label42.TabIndex = 135;
            this.label42.Text = "Telefonos de Emergencia";
            // 
            // texttelefonos_emergencia
            // 
            this.texttelefonos_emergencia.Location = new System.Drawing.Point(750, 272);
            this.texttelefonos_emergencia.Name = "texttelefonos_emergencia";
            this.texttelefonos_emergencia.Size = new System.Drawing.Size(183, 20);
            this.texttelefonos_emergencia.TabIndex = 136;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(861, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(28, 13);
            this.label43.TabIndex = 137;
            this.label43.Text = "Foto";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(816, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 95);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 138;
            this.pictureBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Documento,
            this.Nombres,
            this.Apellidos,
            this.Correo,
            this.Telefono,
            this.Direccion,
            this.Nacionalidad,
            this.Año,
            this.Mes,
            this.Dia});
            this.dataGridView1.Location = new System.Drawing.Point(12, 427);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1045, 60);
            this.dataGridView1.TabIndex = 139;
            // 
            // Documento
            // 
            this.Documento.HeaderText = "Documento";
            this.Documento.Name = "Documento";
            // 
            // Nombres
            // 
            this.Nombres.HeaderText = "Nombres";
            this.Nombres.Name = "Nombres";
            // 
            // Apellidos
            // 
            this.Apellidos.HeaderText = "Apellidos";
            this.Apellidos.Name = "Apellidos";
            // 
            // Correo
            // 
            this.Correo.HeaderText = "Correo";
            this.Correo.Name = "Correo";
            // 
            // Telefono
            // 
            this.Telefono.HeaderText = "Telefono";
            this.Telefono.Name = "Telefono";
            // 
            // Direccion
            // 
            this.Direccion.HeaderText = "Direccion";
            this.Direccion.Name = "Direccion";
            // 
            // Nacionalidad
            // 
            this.Nacionalidad.HeaderText = "Nacionalidad";
            this.Nacionalidad.Name = "Nacionalidad";
            // 
            // Año
            // 
            this.Año.HeaderText = "Año";
            this.Año.Name = "Año";
            // 
            // Mes
            // 
            this.Mes.HeaderText = "Mes";
            this.Mes.Name = "Mes";
            // 
            // Dia
            // 
            this.Dia.HeaderText = "Dia";
            this.Dia.Name = "Dia";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Pais,
            this.Provincia,
            this.Canton,
            this.Paroquia});
            this.dataGridView2.Location = new System.Drawing.Point(12, 493);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(439, 75);
            this.dataGridView2.TabIndex = 140;
            // 
            // Pais
            // 
            this.Pais.HeaderText = "Pais";
            this.Pais.Name = "Pais";
            // 
            // Provincia
            // 
            this.Provincia.HeaderText = "Provincia";
            this.Provincia.Name = "Provincia";
            // 
            // Canton
            // 
            this.Canton.HeaderText = "Canton";
            this.Canton.Name = "Canton";
            // 
            // Paroquia
            // 
            this.Paroquia.HeaderText = "Parroquia";
            this.Paroquia.Name = "Paroquia";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToOrderColumns = true;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn9});
            this.dataGridView3.Location = new System.Drawing.Point(12, 574);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1045, 76);
            this.dataGridView3.TabIndex = 141;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Estado Civil";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Estudios Primarios";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Estudios Secundarios";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Titulo";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Final Estudios Secundarios";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Unidad Educativa";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Ciclo";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Carrera";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "Titulo Estudios Superiores";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "Trabajo";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AllowUserToOrderColumns = true;
            this.dataGridView4.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.Edad,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this.dataGridView4.Location = new System.Drawing.Point(12, 656);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(543, 71);
            this.dataGridView4.TabIndex = 142;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "Tipo de Sangre";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // Edad
            // 
            this.Edad.HeaderText = "Edad";
            this.Edad.Name = "Edad";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "Raza";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Peso";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "Estatura";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToOrderColumns = true;
            this.dataGridView5.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19});
            this.dataGridView5.Location = new System.Drawing.Point(561, 656);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(543, 86);
            this.dataGridView5.TabIndex = 143;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "Vive fuera de Loja";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "Sufre alguna Enfermedad";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.HeaderText = "Recibe Tratamiento Medico";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "Sufre Alguna Discapacidad";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.HeaderText = "Telefoos de Emergencia";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // btneliminar
            // 
            this.btneliminar.Location = new System.Drawing.Point(831, 321);
            this.btneliminar.Name = "btneliminar";
            this.btneliminar.Size = new System.Drawing.Size(75, 42);
            this.btneliminar.TabIndex = 144;
            this.btneliminar.Text = "Eliminar";
            this.toolTip1.SetToolTip(this.btneliminar, "BOTON ELIMINAR");
            this.btneliminar.UseVisualStyleBackColor = true;
            // 
            // btnactualizar
            // 
            this.btnactualizar.Location = new System.Drawing.Point(831, 381);
            this.btnactualizar.Name = "btnactualizar";
            this.btnactualizar.Size = new System.Drawing.Size(75, 40);
            this.btnactualizar.TabIndex = 145;
            this.btnactualizar.Text = "Actualizar";
            this.toolTip1.SetToolTip(this.btnactualizar, "BOTON ACTUALIZAR");
            this.btnactualizar.UseVisualStyleBackColor = true;
            // 
            // btnmodificar
            // 
            this.btnmodificar.Location = new System.Drawing.Point(750, 381);
            this.btnmodificar.Name = "btnmodificar";
            this.btnmodificar.Size = new System.Drawing.Size(75, 40);
            this.btnmodificar.TabIndex = 146;
            this.btnmodificar.Text = "Modificar";
            this.toolTip1.SetToolTip(this.btnmodificar, "BOTON MODIFICAR");
            this.btnmodificar.UseVisualStyleBackColor = true;
            this.btnmodificar.Click += new System.EventHandler(this.btnmodificar_Click);
            // 
            // btnguardar
            // 
            this.btnguardar.Location = new System.Drawing.Point(750, 321);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(75, 42);
            this.btnguardar.TabIndex = 147;
            this.btnguardar.Text = "Guardar";
            this.toolTip1.SetToolTip(this.btnguardar, "BOTON DE GUARDAR");
            this.btnguardar.UseVisualStyleBackColor = true;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // cboprovincia
            // 
            this.cboprovincia.FormattingEnabled = true;
            this.cboprovincia.Items.AddRange(new object[] {
            "Loja",
            "Azuay",
            "Zamora Chimchipe",
            "El Oro",
            "Guayas",
            "Santa Elena",
            "Manabi",
            "Los Rios",
            "Esmeraldas",
            "Cañar",
            "Chimborazo",
            "Bolivar",
            "Tunguragua",
            "Cotopaxi",
            "PICHINCHA",
            "SANTO DOMINGO DE LOS TSACHILAS",
            "IMBABURA",
            "CARCHI",
            "SUCUMBIOS",
            "NAPO",
            "ORELLANA",
            "PASTAZA",
            "MORONA SANTIAGO",
            "GALAPAGOS"});
            this.cboprovincia.Location = new System.Drawing.Point(193, 365);
            this.cboprovincia.Name = "cboprovincia";
            this.cboprovincia.Size = new System.Drawing.Size(142, 21);
            this.cboprovincia.TabIndex = 148;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1104, 741);
            this.Controls.Add(this.cboprovincia);
            this.Controls.Add(this.btnguardar);
            this.Controls.Add(this.btnmodificar);
            this.Controls.Add(this.btnactualizar);
            this.Controls.Add(this.btneliminar);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.texttelefonos_emergencia);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.cbodiscapacidad);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.cbomedicacion);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.textenfermedad);
            this.Controls.Add(this.cboenfermedad);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.cboraza);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.cbotrabajo);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.textviveen_loja);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.cboviveenloja);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.texttitulo_superior);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.cbosuperior);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.cbofinalizacionestudios_secundarios);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.textpeso);
            this.Controls.Add(this.textestatura);
            this.Controls.Add(this.textedad);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.cbotipo_sangre);
            this.Controls.Add(this.texttitulo);
            this.Controls.Add(this.textestudios_secundarios);
            this.Controls.Add(this.textestudios_primarios);
            this.Controls.Add(this.cboestado_civil);
            this.Controls.Add(this.cbocarrera);
            this.Controls.Add(this.textunidad_educativa);
            this.Controls.Add(this.cbociclo);
            this.Controls.Add(this.cboparroquia);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.cbocanton);
            this.Controls.Add(this.textaño);
            this.Controls.Add(this.textpais);
            this.Controls.Add(this.texttelefono);
            this.Controls.Add(this.cbodocumento);
            this.Controls.Add(this.cbodia);
            this.Controls.Add(this.cbomes);
            this.Controls.Add(this.textcorreo);
            this.Controls.Add(this.textdocumento);
            this.Controls.Add(this.textnacionalidad);
            this.Controls.Add(this.cbotelefono);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textdireccion);
            this.Controls.Add(this.textapellidos);
            this.Controls.Add(this.textnombres);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textnombres;
        private System.Windows.Forms.TextBox textapellidos;
        private System.Windows.Forms.TextBox textdireccion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textcorreo;
        private System.Windows.Forms.TextBox textdocumento;
        private System.Windows.Forms.TextBox textnacionalidad;
        private System.Windows.Forms.ComboBox cbotelefono;
        private System.Windows.Forms.ComboBox cbodia;
        private System.Windows.Forms.ComboBox cbomes;
        private System.Windows.Forms.ComboBox cbodocumento;
        private System.Windows.Forms.TextBox texttelefono;
        private System.Windows.Forms.TextBox textpais;
        private System.Windows.Forms.TextBox textaño;
        private System.Windows.Forms.ComboBox cbocanton;
        private System.Windows.Forms.ComboBox cboparroquia;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox texttitulo;
        private System.Windows.Forms.TextBox textestudios_secundarios;
        private System.Windows.Forms.TextBox textestudios_primarios;
        private System.Windows.Forms.ComboBox cboestado_civil;
        private System.Windows.Forms.ComboBox cbocarrera;
        private System.Windows.Forms.TextBox textunidad_educativa;
        private System.Windows.Forms.ComboBox cbociclo;
        private System.Windows.Forms.ComboBox cbotipo_sangre;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textedad;
        private System.Windows.Forms.TextBox textestatura;
        private System.Windows.Forms.TextBox textpeso;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cbofinalizacionestudios_secundarios;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox cbosuperior;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox texttitulo_superior;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.ComboBox cboviveenloja;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textviveen_loja;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.ComboBox cbotrabajo;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.ComboBox cboraza;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox cboenfermedad;
        private System.Windows.Forms.TextBox textenfermedad;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.ComboBox cbomedicacion;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox cbodiscapacidad;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox texttelefonos_emergencia;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Documento;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombres;
        private System.Windows.Forms.DataGridViewTextBoxColumn Apellidos;
        private System.Windows.Forms.DataGridViewTextBoxColumn Correo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telefono;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direccion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nacionalidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Año;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mes;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dia;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Pais;
        private System.Windows.Forms.DataGridViewTextBoxColumn Provincia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Canton;
        private System.Windows.Forms.DataGridViewTextBoxColumn Paroquia;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Edad;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.Button btneliminar;
        private System.Windows.Forms.Button btnactualizar;
        private System.Windows.Forms.Button btnmodificar;
        private System.Windows.Forms.Button btnguardar;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.ComboBox cboprovincia;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

