﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }
        int ancho = 60;
        int alto = 60;

        private void unionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Prueba Submenu");
        }

        private void cuadradoMagicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hola Mundo");
        }

        private void latinaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (latinaToolStripMenuItem.Checked==true)
            {
                MessageBox.Show("Activo");
                latinaToolStripMenuItem.Checked = false;
            }
            else
            {
                MessageBox.Show("Pasivo");
            }
        }

        private void interseccionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (interseccionToolStripMenuItem.Checked == true)
            {
                MessageBox.Show("Activo");
                interseccionToolStripMenuItem.Checked = false;
            }
            else
            {
                MessageBox.Show("Pasivo");
            }

        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
           
           
        }

        private void toolStripComboBox1_EnabledChanged(object sender, EventArgs e)
        {
            
        }

        private void toolStripComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (toolStripComboBox1.SelectedIndex == 0)
            {
                MessageBox.Show("Serie Basica");
            }
            else 
            {
                if (toolStripComboBox1.SelectedIndex == 1){
                MessageBox.Show("Serie Media");
                }
            else 
                {
                    if (toolStripComboBox1.SelectedIndex == 2){
                MessageBox.Show("Serie Compleja");
               }
               }
           }
        
        }

        private void vsbrojo_Scroll(object sender, ScrollEventArgs e)
        {
            lblcolor1.BackColor = Color.FromArgb(vsbrojo.Value,vsbverde.Value,vsbazul.Value); //Seleccionar la gama de colores que  yo tengo

        }

        private void vsbverde_Scroll(object sender, ScrollEventArgs e)
        {
            lblcolor1.BackColor = Color.FromArgb(vsbrojo.Value, vsbverde.Value, vsbazul.Value);
        }

        private void vsbazul_Scroll(object sender, ScrollEventArgs e)
        {
            lblcolor1.BackColor = Color.FromArgb(vsbrojo.Value, vsbverde.Value, vsbazul.Value);
        }

        private void hsancho_Scroll(object sender, ScrollEventArgs e)
        {
            ancho = 60+ hsancho.Value;
            pb1.Size = new Size(ancho,alto);
        }

        private void vsbalto_Scroll(object sender, ScrollEventArgs e)
        {
            alto = 60 + vsbalto.Value;
            pb1.Size = new Size(ancho,alto);
        }

        private void vectoresToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
