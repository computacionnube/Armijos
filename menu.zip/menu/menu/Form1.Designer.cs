﻿namespace Menu
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.vectoresToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.interseccionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.diferenciaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.matricesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cuadradaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.latinaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.cuadradoMagicoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.lblcolor1 = new System.Windows.Forms.Label();
            this.vsbrojo = new System.Windows.Forms.VScrollBar();
            this.vsbazul = new System.Windows.Forms.VScrollBar();
            this.vsbverde = new System.Windows.Forms.VScrollBar();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.vsbalto = new System.Windows.Forms.VScrollBar();
            this.hsancho = new System.Windows.Forms.HScrollBar();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.vectoresToolStripMenuItem,
            this.matricesToolStripMenuItem,
            this.salirToolStripMenuItem,
            this.toolStripComboBox1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(470, 27);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // vectoresToolStripMenuItem
            // 
            this.vectoresToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.vectoresToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.unionToolStripMenuItem,
            this.interseccionToolStripMenuItem,
            this.toolStripMenuItem1,
            this.diferenciaToolStripMenuItem});
            this.vectoresToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("vectoresToolStripMenuItem.Image")));
            this.vectoresToolStripMenuItem.Name = "vectoresToolStripMenuItem";
            this.vectoresToolStripMenuItem.Size = new System.Drawing.Size(79, 23);
            this.vectoresToolStripMenuItem.Text = "&Vectores";
            this.vectoresToolStripMenuItem.Click += new System.EventHandler(this.vectoresToolStripMenuItem_Click);
            // 
            // unionToolStripMenuItem
            // 
            this.unionToolStripMenuItem.Name = "unionToolStripMenuItem";
            this.unionToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D1)));
            this.unionToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.unionToolStripMenuItem.Text = "Union";
            this.unionToolStripMenuItem.Click += new System.EventHandler(this.unionToolStripMenuItem_Click);
            // 
            // interseccionToolStripMenuItem
            // 
            this.interseccionToolStripMenuItem.Checked = true;
            this.interseccionToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.interseccionToolStripMenuItem.Name = "interseccionToolStripMenuItem";
            this.interseccionToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.interseccionToolStripMenuItem.Text = "Interseccion";
            this.interseccionToolStripMenuItem.Click += new System.EventHandler(this.interseccionToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(143, 6);
            // 
            // diferenciaToolStripMenuItem
            // 
            this.diferenciaToolStripMenuItem.Name = "diferenciaToolStripMenuItem";
            this.diferenciaToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.diferenciaToolStripMenuItem.Text = "Diferencia";
            // 
            // matricesToolStripMenuItem
            // 
            this.matricesToolStripMenuItem.BackColor = System.Drawing.SystemColors.Highlight;
            this.matricesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cuadradaToolStripMenuItem,
            this.latinaToolStripMenuItem,
            this.toolStripMenuItem2,
            this.cuadradoMagicoToolStripMenuItem});
            this.matricesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("matricesToolStripMenuItem.Image")));
            this.matricesToolStripMenuItem.Name = "matricesToolStripMenuItem";
            this.matricesToolStripMenuItem.Size = new System.Drawing.Size(80, 23);
            this.matricesToolStripMenuItem.Text = "&Matrices";
            this.matricesToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            // 
            // cuadradaToolStripMenuItem
            // 
            this.cuadradaToolStripMenuItem.Name = "cuadradaToolStripMenuItem";
            this.cuadradaToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.cuadradaToolStripMenuItem.Text = "Cuadrada";
            // 
            // latinaToolStripMenuItem
            // 
            this.latinaToolStripMenuItem.Checked = true;
            this.latinaToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.latinaToolStripMenuItem.Name = "latinaToolStripMenuItem";
            this.latinaToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.latinaToolStripMenuItem.Text = "Latina";
            this.latinaToolStripMenuItem.ToolTipText = "Cuadrado latino";
            this.latinaToolStripMenuItem.Click += new System.EventHandler(this.latinaToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(205, 6);
            // 
            // cuadradoMagicoToolStripMenuItem
            // 
            this.cuadradoMagicoToolStripMenuItem.Name = "cuadradoMagicoToolStripMenuItem";
            this.cuadradoMagicoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.cuadradoMagicoToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.cuadradoMagicoToolStripMenuItem.Text = "CuadradoMagico";
            this.cuadradoMagicoToolStripMenuItem.Click += new System.EventHandler(this.cuadradoMagicoToolStripMenuItem_Click);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(41, 23);
            this.salirToolStripMenuItem.Text = "&Salir";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.toolStripComboBox1.Items.AddRange(new object[] {
            "Serie 1 ",
            "Serie 2",
            "Serie 3"});
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(121, 23);
            this.toolStripComboBox1.Text = "Opcion";
            this.toolStripComboBox1.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox1_SelectedIndexChanged);
            this.toolStripComboBox1.Click += new System.EventHandler(this.toolStripComboBox1_Click);
            this.toolStripComboBox1.EnabledChanged += new System.EventHandler(this.toolStripComboBox1_EnabledChanged);
            // 
            // lblcolor1
            // 
            this.lblcolor1.BackColor = System.Drawing.Color.Teal;
            this.lblcolor1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblcolor1.Location = new System.Drawing.Point(122, 68);
            this.lblcolor1.Name = "lblcolor1";
            this.lblcolor1.Size = new System.Drawing.Size(128, 95);
            this.lblcolor1.TabIndex = 1;
            // 
            // vsbrojo
            // 
            this.vsbrojo.LargeChange = 5;
            this.vsbrojo.Location = new System.Drawing.Point(9, 68);
            this.vsbrojo.Maximum = 255;
            this.vsbrojo.Name = "vsbrojo";
            this.vsbrojo.Size = new System.Drawing.Size(18, 95);
            this.vsbrojo.TabIndex = 2;
            this.vsbrojo.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbrojo_Scroll);
            // 
            // vsbazul
            // 
            this.vsbazul.LargeChange = 5;
            this.vsbazul.Location = new System.Drawing.Point(83, 68);
            this.vsbazul.Maximum = 255;
            this.vsbazul.Name = "vsbazul";
            this.vsbazul.Size = new System.Drawing.Size(18, 95);
            this.vsbazul.TabIndex = 3;
            this.vsbazul.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbazul_Scroll);
            // 
            // vsbverde
            // 
            this.vsbverde.LargeChange = 5;
            this.vsbverde.Location = new System.Drawing.Point(49, 68);
            this.vsbverde.Maximum = 255;
            this.vsbverde.Name = "vsbverde";
            this.vsbverde.Size = new System.Drawing.Size(18, 95);
            this.vsbverde.TabIndex = 4;
            this.vsbverde.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbverde_Scroll);
            // 
            // pb1
            // 
            this.pb1.Image = ((System.Drawing.Image)(resources.GetObject("pb1.Image")));
            this.pb1.Location = new System.Drawing.Point(311, 77);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(81, 74);
            this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb1.TabIndex = 5;
            this.pb1.TabStop = false;
            // 
            // vsbalto
            // 
            this.vsbalto.Location = new System.Drawing.Point(284, 68);
            this.vsbalto.Name = "vsbalto";
            this.vsbalto.Size = new System.Drawing.Size(24, 95);
            this.vsbalto.TabIndex = 6;
            this.vsbalto.Scroll += new System.Windows.Forms.ScrollEventHandler(this.vsbalto_Scroll);
            // 
            // hsancho
            // 
            this.hsancho.Location = new System.Drawing.Point(291, 48);
            this.hsancho.Name = "hsancho";
            this.hsancho.Size = new System.Drawing.Size(118, 20);
            this.hsancho.TabIndex = 7;
            this.hsancho.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hsancho_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(470, 261);
            this.Controls.Add(this.hsancho);
            this.Controls.Add(this.vsbalto);
            this.Controls.Add(this.pb1);
            this.Controls.Add(this.vsbverde);
            this.Controls.Add(this.vsbazul);
            this.Controls.Add(this.vsbrojo);
            this.Controls.Add(this.lblcolor1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem vectoresToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem interseccionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem diferenciaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem matricesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cuadradaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem latinaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem cuadradoMagicoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.Label lblcolor1;
        private System.Windows.Forms.VScrollBar vsbrojo;
        private System.Windows.Forms.VScrollBar vsbazul;
        private System.Windows.Forms.VScrollBar vsbverde;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.VScrollBar vsbalto;
        private System.Windows.Forms.HScrollBar hsancho;
    }
}

