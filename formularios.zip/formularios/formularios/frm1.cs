﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace formularios
{
    public partial class frm1 : Form
    {
        public frm1()
        {
            InitializeComponent();
        }
        

        private void btncerrar1_Click(object sender, EventArgs e)
        {
            Form1.ActiveForm.Show();
            this.Close();
        }
    }
}
