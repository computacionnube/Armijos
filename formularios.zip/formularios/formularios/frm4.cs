﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace formularios
{
    public partial class frm4 : Form
    {
        frmnuevo objnuevo = new frmnuevo(); //cuando da click en presenta se crea el objeto

        public frm4()
        {
            InitializeComponent();
        }

        private void btnpresenta_Click(object sender, EventArgs e)
        {
            objnuevo.Show(); // para hacerlo visible

        }

        private void btnrepite_Click(object sender, EventArgs e)
        {
            objnuevo.Visible = true;
        }

        private void btncerrar4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
