﻿namespace formularios
{
    partial class frm4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncerrar4 = new System.Windows.Forms.Button();
            this.btnpresenta = new System.Windows.Forms.Button();
            this.btnrepite = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btncerrar4
            // 
            this.btncerrar4.Location = new System.Drawing.Point(76, 100);
            this.btncerrar4.Name = "btncerrar4";
            this.btncerrar4.Size = new System.Drawing.Size(75, 23);
            this.btncerrar4.TabIndex = 6;
            this.btncerrar4.Text = "Cerrar";
            this.btncerrar4.UseVisualStyleBackColor = true;
            this.btncerrar4.Click += new System.EventHandler(this.btncerrar4_Click);
            // 
            // btnpresenta
            // 
            this.btnpresenta.Location = new System.Drawing.Point(31, 40);
            this.btnpresenta.Name = "btnpresenta";
            this.btnpresenta.Size = new System.Drawing.Size(75, 23);
            this.btnpresenta.TabIndex = 7;
            this.btnpresenta.Text = "Presenta";
            this.btnpresenta.UseVisualStyleBackColor = true;
            this.btnpresenta.Click += new System.EventHandler(this.btnpresenta_Click);
            // 
            // btnrepite
            // 
            this.btnrepite.Location = new System.Drawing.Point(122, 39);
            this.btnrepite.Name = "btnrepite";
            this.btnrepite.Size = new System.Drawing.Size(75, 23);
            this.btnrepite.TabIndex = 8;
            this.btnrepite.Text = "Repite";
            this.btnrepite.UseVisualStyleBackColor = true;
            this.btnrepite.Click += new System.EventHandler(this.btnrepite_Click);
            // 
            // frm4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnrepite);
            this.Controls.Add(this.btnpresenta);
            this.Controls.Add(this.btncerrar4);
            this.Name = "frm4";
            this.Text = "frm4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btncerrar4;
        private System.Windows.Forms.Button btnpresenta;
        private System.Windows.Forms.Button btnrepite;
    }
}