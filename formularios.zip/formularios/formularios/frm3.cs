﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace formularios
{
    public partial class frm3 : Form
    {
        public frm3()
        {
            InitializeComponent();
        }

        private void btncerrar3_Click(object sender, EventArgs e)
        {
            frm3.ActiveForm.Close();//Cerrar para limitar el movimiento
        }

        private void frm3_Load(object sender, EventArgs e)
        {

        }

        private void agregar1()
        {
            litboxnum1.Items.Add(txtnum1);
            txtnum1.Text = "";

        }
        private void agregar2()
        {
            litboxnum2.Items.Add(txtnum2);
            txtnum2.Text = "";
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            this.agregar1();
            litboxnum1.Text = txtnum1.Text;
          
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            this.agregar2();
        }
    }
}
