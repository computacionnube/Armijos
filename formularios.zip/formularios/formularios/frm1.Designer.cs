﻿namespace formularios
{
    partial class frm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncerrar1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btncerrar1
            // 
            this.btncerrar1.Location = new System.Drawing.Point(139, 106);
            this.btncerrar1.Name = "btncerrar1";
            this.btncerrar1.Size = new System.Drawing.Size(75, 23);
            this.btncerrar1.TabIndex = 4;
            this.btncerrar1.Text = "Cerrar";
            this.btncerrar1.UseVisualStyleBackColor = true;
            this.btncerrar1.Click += new System.EventHandler(this.btncerrar1_Click);
            // 
            // frm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(376, 261);
            this.Controls.Add(this.btncerrar1);
            this.Name = "frm1";
            this.Text = "frm1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btncerrar1;
    }
}