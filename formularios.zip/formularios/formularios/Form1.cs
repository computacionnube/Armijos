﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace formularios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btneje1_Click(object sender, EventArgs e)
        {
            frm1 objejer1 =new frm1();
            objejer1.Text = "Ejercicio de Arreglos";
            objejer1.MaximizeBox = false;
            objejer1.Show();

        }

        private void btnejer2_Click(object sender, EventArgs e)
        {
            frm2 objejer2 = new frm2();
            objejer2.Text = "Formulario Maximizado";
            objejer2.WindowState = FormWindowState.Maximized; //estado de la ventana de Windows
            objejer2.Show();
        }

        private void btnejer3_Click(object sender, EventArgs e)
        {
            frm3 objejer3 = new frm3();
            this.Hide(); //oculta formulario
            objejer3.ShowDialog();
            this.Visible = true;
        }

        private void btnejer4_Click(object sender, EventArgs e)
        {
            frm4 objejer4 = new frm4();
            
            objejer4.ShowDialog();//mensajes 
        }
    }
}
