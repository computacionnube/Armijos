﻿namespace formularios
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btneje1 = new System.Windows.Forms.Button();
            this.btnejer4 = new System.Windows.Forms.Button();
            this.btnejer2 = new System.Windows.Forms.Button();
            this.btncancelar = new System.Windows.Forms.Button();
            this.btnejer3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btneje1
            // 
            this.btneje1.Location = new System.Drawing.Point(32, 54);
            this.btneje1.Name = "btneje1";
            this.btneje1.Size = new System.Drawing.Size(75, 23);
            this.btneje1.TabIndex = 0;
            this.btneje1.Text = "Ejercicio 1";
            this.btneje1.UseVisualStyleBackColor = true;
            this.btneje1.Click += new System.EventHandler(this.btneje1_Click);
            // 
            // btnejer4
            // 
            this.btnejer4.Location = new System.Drawing.Point(32, 142);
            this.btnejer4.Name = "btnejer4";
            this.btnejer4.Size = new System.Drawing.Size(75, 23);
            this.btnejer4.TabIndex = 1;
            this.btnejer4.Text = "Ejercicio 4";
            this.btnejer4.UseVisualStyleBackColor = true;
            this.btnejer4.Click += new System.EventHandler(this.btnejer4_Click);
            // 
            // btnejer2
            // 
            this.btnejer2.Location = new System.Drawing.Point(171, 53);
            this.btnejer2.Name = "btnejer2";
            this.btnejer2.Size = new System.Drawing.Size(75, 23);
            this.btnejer2.TabIndex = 2;
            this.btnejer2.Text = "Ejercicio 2";
            this.btnejer2.UseVisualStyleBackColor = true;
            this.btnejer2.Click += new System.EventHandler(this.btnejer2_Click);
            // 
            // btncancelar
            // 
            this.btncancelar.Location = new System.Drawing.Point(171, 142);
            this.btncancelar.Name = "btncancelar";
            this.btncancelar.Size = new System.Drawing.Size(75, 23);
            this.btncancelar.TabIndex = 3;
            this.btncancelar.Text = "Cancelar";
            this.btncancelar.UseVisualStyleBackColor = true;
            // 
            // btnejer3
            // 
            this.btnejer3.Location = new System.Drawing.Point(97, 98);
            this.btnejer3.Name = "btnejer3";
            this.btnejer3.Size = new System.Drawing.Size(75, 23);
            this.btnejer3.TabIndex = 4;
            this.btnejer3.Text = "Ejercicio 3";
            this.btnejer3.UseVisualStyleBackColor = true;
            this.btnejer3.Click += new System.EventHandler(this.btnejer3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnejer3);
            this.Controls.Add(this.btncancelar);
            this.Controls.Add(this.btnejer2);
            this.Controls.Add(this.btnejer4);
            this.Controls.Add(this.btneje1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btneje1;
        private System.Windows.Forms.Button btnejer4;
        private System.Windows.Forms.Button btnejer2;
        private System.Windows.Forms.Button btncancelar;
        private System.Windows.Forms.Button btnejer3;
    }
}

