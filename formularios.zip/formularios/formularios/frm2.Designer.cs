﻿namespace formularios
{
    partial class frm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm2));
            this.btncerrar2 = new System.Windows.Forms.Button();
            this.listaimagen = new System.Windows.Forms.ImageList(this.components);
            this.pictpantalla = new System.Windows.Forms.PictureBox();
            this.Reloj = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictpantalla)).BeginInit();
            this.SuspendLayout();
            // 
            // btncerrar2
            // 
            this.btncerrar2.Location = new System.Drawing.Point(99, 192);
            this.btncerrar2.Name = "btncerrar2";
            this.btncerrar2.Size = new System.Drawing.Size(75, 23);
            this.btncerrar2.TabIndex = 5;
            this.btncerrar2.Text = "Cerrar";
            this.btncerrar2.UseVisualStyleBackColor = true;
            this.btncerrar2.Click += new System.EventHandler(this.btncerrar2_Click);
            // 
            // listaimagen
            // 
            this.listaimagen.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("listaimagen.ImageStream")));
            this.listaimagen.TransparentColor = System.Drawing.Color.Transparent;
            this.listaimagen.Images.SetKeyName(0, "20190329_102132.jpg");
            this.listaimagen.Images.SetKeyName(1, "20190329_102138.jpg");
            this.listaimagen.Images.SetKeyName(2, "59285364_1713528532127264_6529062039015391232_n.jpg");
            this.listaimagen.Images.SetKeyName(3, "59008870_2231580460268104_8387281525120434176_n.jpg");
            // 
            // pictpantalla
            // 
            this.pictpantalla.Location = new System.Drawing.Point(43, 26);
            this.pictpantalla.Name = "pictpantalla";
            this.pictpantalla.Size = new System.Drawing.Size(172, 160);
            this.pictpantalla.TabIndex = 6;
            this.pictpantalla.TabStop = false;
            // 
            // Reloj
            // 
            this.Reloj.Enabled = true;
            this.Reloj.Interval = 1000;
            this.Reloj.Tick += new System.EventHandler(this.Reloj_Tick);
            // 
            // frm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.pictpantalla);
            this.Controls.Add(this.btncerrar2);
            this.MaximizeBox = false;
            this.Name = "frm2";
            this.Text = "frm2";
            this.Load += new System.EventHandler(this.frm2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictpantalla)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btncerrar2;
        private System.Windows.Forms.ImageList listaimagen;
        private System.Windows.Forms.PictureBox pictpantalla;
        private System.Windows.Forms.Timer Reloj;
    }
}