﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace formularios
{
    public partial class frm2 : Form
    {
        int img = 0;
        public frm2()
        {
            InitializeComponent();
        }

        private void btncerrar2_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void Reloj_Tick(object sender, EventArgs e)
        {
            pictpantalla.Image = listaimagen.Images[img];
            img++;
            if (img ==4)
            {
                img = 0;
                
            }
        }

        private void frm2_Load(object sender, EventArgs e)
        {

        }
    }
}
