﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace imagenmovimiento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            RELoj.Enabled = true;
        }
        int x1 = 23, y1 = 23;
        int sigx = 1, sigy = 1;

        private void RELoj_Tick(object sender, EventArgs e)
        {
            if(x1 + 23 <= this.Size.Width && x1>0)
            {
                pictureBox1.Location = new Point(x1 += 10 * sigx, y1);
                if (x1 <= 1)
                {
                    sigy *= -1;
                    y1 -= 10;
                    x1 = 1; 
                }
            }
            if (x1 +23 >= this.Size.Width || x1 == 1)
            {
                //if (x1 + 50 >= this.Size.Width && y1 < 70)
                //{
                //    sigy *= -1;
                //}
                pictureBox1.Location = new Point(x1, y1 += 10 * sigy);
                if(y1 + 23 >= this.Size.Height || y1 < 23)
                {                    
                    if (y1 > 23)
                    {
                        x1 -= 10;
                        y1 = 1;
                        sigx *= -1;
                    }
                }          
            }
        }

        private void btniniciar_Click(object sender, EventArgs e)
        {
            RELoj.Enabled = true;
        }

        private void btnparar_Click(object sender, EventArgs e)
        {
            RELoj.Enabled = false;
        }

        
    }
}
