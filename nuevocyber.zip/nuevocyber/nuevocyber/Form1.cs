﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace nuevocyber
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            costo_hora = 1.00;
            costo_minuto = costo_hora / 100;
        }
        int dd = 0, dd2 = 0, dd3 = 0, dd4 = 0, dd5 = 0, dd6 = 0;
        int ss = 0, ss2 = 0, ss3 = 0, ss4 = 0, ss5 = 0, ss6 = 0;
        int mm = 0, mm2 = 0, mm3 = 0, mm4 = 0, mm5 = 0, mm6 = 0;
        int hh = 0, hh2 = 0, hh3 = 0, hh4 = 0, hh5 = 0, hh6 = 0;
        int cont1 = 0, cont2=6;
        double costo_hora; 
        double costo_minuto;
        double costo1 = 00.00;
        double costo2 = 00.00;
        double costo3 = 00.00;
        double costo4 = 00.00;
        double costo5 = 00.00;
        double costo6 = 00.00;
        int c = 60, c2 = 60, c3 = 60, c4 = 60, c5 = 60, c6 = 60;

        private void Reloj1_Tick(object sender, EventArgs e)
        {
            dd++;
            if (dd == 10)
            {
                dd = 0;
                ss++;
                c--;
                if (ss == 60)
                {
                    mm++;
                    ss = 0;
                    c = 60;
                    costo1 += 0.05;
                    label32.Text = costo1.ToString();
                    if (mm == 60)
                    {
                        hh++;
                        mm = 0;
                        costo_hora += 1.00;
                        lblhora.Text = costo_hora.ToString();
                    }
                }
            }
            label26.Text = hh.ToString("0") + ":" + mm2.ToString("00") + ":" + ss2.ToString("00");
            int a = Convert.ToInt16(numericUpDown1.Text) - hh;
            int b = Convert.ToInt16(numericUpDown2.Text) - mm - 1;
            label15.Text = (a.ToString() + ":" + b.ToString() + ":" + c.ToString());
            if (a == 0 && b == -1)
            {
                label13.Text = "Libre";
                label15.Text = "0:0:0";
                Reloj1.Stop();            
            }
        }

        private void btnpc1_Click(object sender, EventArgs e)
        {
            Reloj1.Enabled = true;
            if (Reloj1.Enabled == true)
            {
                cont1 += 1;
                cont2 -= 1;
                groupBox1.Enabled = true;
                btn01.Enabled = true;
                label13.Text = "Ocupado";
            }
            lblocupado.Text = "Ocupado: "   +cont1.ToString("0");
            lbllibre.Text = "Libre: "   +cont2.ToString("0");

            if (numericUpDown1.Enabled == true || numericUpDown2.Enabled == true)
            {
                label13.Text = "Ocupado";
                label26.Text = label26.Text = hh.ToString("0") + ":" + mm.ToString("00") + ":" + ss.ToString("00");
            }           
        }

        private void Reloj2_Tick(object sender, EventArgs e)
        {
            dd2++;
            if (dd2 == 10)
            {
                dd2 = 0;
                ss2++;
                c2--;
                if (ss2 == 60)
                {
                    mm2++;
                    ss2 = 0;
                    c2 = 60;
                    costo2 += 0.05;
                    label35.Text = costo2.ToString();
                    if (mm2 == 60)
                    {
                        hh2++;
                        mm2 = 0;
                        costo_hora += 1.00;
                        lblhora.Text = costo_hora.ToString();
                    }
                }
            }
            label27.Text = hh2.ToString("0") + ":" + mm2.ToString("00") + ":" + ss2.ToString("00");
            int a2 = Convert.ToInt16(numericUpDown1.Text) - hh2;
            int b2 = Convert.ToInt16(numericUpDown2.Text) - mm2 - 1;
            label34.Text = (a2.ToString() + ":" + b2.ToString() + ":" + c2.ToString());
            if (a2 == 0 && b2 == -1)
            {
                label21.Text = "Libre";
                label34.Text = "0:0:0";
                Reloj1.Stop();
            }
        }

        private void btnpc2_Click(object sender, EventArgs e)
        {
            Reloj2.Enabled = true;
            if (Reloj2.Enabled == true)
            {
                cont1 += 1;
                cont2 -= 1;
                groupBox1.Enabled = true;
                btn02.Enabled = true;
                label21.Text = "Ocupado";
            }
            lblocupado.Text = "Ocupado: "   +cont1.ToString("0");
            lbllibre.Text = "Libre: "   +cont2.ToString("0");

            if (numericUpDown1.Enabled == true || numericUpDown2.Enabled == true)
            {
                label21.Text = "Ocupado";
                label27.Text = label27.Text = hh2.ToString("0") + ":" + mm2.ToString("00") + ":" + ss2.ToString("00");
            }
        }

        private void Reloj3_Tick(object sender, EventArgs e)
        {
            dd3++;
            if (dd3 == 10)
            {
                dd3 = 0;
                ss3++;
                c3--;
                if (ss3 == 60)
                {
                    mm3++;
                    ss3 = 0;
                    costo3 += 0.05;
                    c3 = 60;
                    label38.Text = costo3.ToString();
                    if (mm3 == 60)
                    {
                        hh3++;
                        mm3 = 0;
                        costo_hora += 1.00;
                        lblhora.Text = costo_hora.ToString();
                    }
                }
            }
            label28.Text = hh3.ToString("0") + ":" + mm3.ToString("00") + ":" + ss3.ToString("00");
            int a3 = Convert.ToInt16(numericUpDown1.Text) - hh3;
            int b3 = Convert.ToInt16(numericUpDown2.Text) - mm3 - 1;
            label37.Text = (a3.ToString() + ":" + b3.ToString() + ":" + c3.ToString());
            if (a3 == 0 && b3 == -1)
            {
                label22.Text = "Libre";
                label37.Text = "0:0:0";
                Reloj3.Stop();
            }
        }

        private void btnpc3_Click(object sender, EventArgs e)
        {
            Reloj3.Enabled = true;
            if (Reloj3.Enabled == true)
            {
                cont1 += 1;
                cont2 -= 1;
                groupBox1.Enabled = true;
                btn03.Enabled = true;
                label22.Text = "Ocupado";
            }
            lblocupado.Text = "Ocupado: "   +cont1.ToString("0");
            lbllibre.Text = "Libre: "   +cont2.ToString("0");

            if (numericUpDown1.Enabled == true || numericUpDown2.Enabled == true)
            {              
                label22.Text = "Ocupado";
                label28.Text = label28.Text = hh3.ToString("0") + ":" + mm3.ToString("00") + ":" + ss3.ToString("00");
            }
        }

        private void Reloj4_Tick(object sender, EventArgs e)
        {
            dd4++;
            if (dd4 == 10)
            {
                dd4 = 0;
                ss4++;
                c4--;
                if (ss4 == 60)
                {
                    mm4++;
                    ss4 = 0;
                    c4 = 60;
                    costo4 += 0.05;
                    label41.Text = costo4.ToString();
                    if (mm4 == 60)
                    {
                        hh4++;
                        mm4 = 0;
                        costo_hora += 1.00;
                        lblhora.Text = costo_hora.ToString();
                    }
                }
            }
            label29.Text = hh4.ToString("0") + ":" + mm4.ToString("00") + ":" + ss4.ToString("00");
            int a4 = Convert.ToInt16(numericUpDown1.Text) - hh4;
            int b4 = Convert.ToInt16(numericUpDown2.Text) - mm4 - 1;
            label40.Text = (a4.ToString() + ":" + b4.ToString() + ":" + c4.ToString());
            if (a4 == 0 && b4 == -1)
            {
                label23.Text = "Libre";
                label40.Text = "0:0:0";
                Reloj4.Stop();
            }
        }

        private void btnpc4_Click(object sender, EventArgs e)
        {
            Reloj4.Enabled = true;
            if (Reloj4.Enabled == true)
            {
                cont1 += 1;
                cont2 -= 1;
                groupBox1.Enabled = true;
                btn04.Enabled = true;
                label23.Text = "Ocupado";
            }
            lblocupado.Text = "Ocupado: "   +cont1.ToString("0");
            lbllibre.Text = "Libre: "   +cont2.ToString("0");

            if (numericUpDown1.Enabled == true || numericUpDown2.Enabled == true)
            {
                label23.Text = "Ocupado";
                label29.Text = label29.Text = hh4.ToString("0") + ":" + mm4.ToString("00") + ":" + ss4.ToString("00");
            }
        }

        private void Reloj5_Tick(object sender, EventArgs e)
        {
            dd5++;
            if (dd5 == 10)
            {
                dd5 = 0;
                ss5++;
                c5--;
                if (ss5 == 60)
                {
                    mm5++;
                    ss5 = 0;
                    c5 = 60;
                    costo5 += 0.05;
                    label44.Text = costo5.ToString();
                    if (mm5 == 60)
                    {
                        hh5++;
                        mm5 = 0;
                        costo_hora += 1.00;
                        lblhora.Text = costo_hora.ToString();
                    }
                }
            }
            label30.Text = hh5.ToString("0") + ":" + mm5.ToString("00") + ":" + ss5.ToString("00");
            int a5 = Convert.ToInt16(numericUpDown1.Text) - hh5;
            int b5 = Convert.ToInt16(numericUpDown2.Text) - mm5 - 1;
            label43.Text = (a5.ToString() + ":" + b5.ToString() + ":" + c5.ToString());
            if (a5 == 0 && b5 == -1)
            {
                label24.Text = "Libre";
                label43.Text = "0:0:0";
                Reloj5.Stop();
            }
        }

        private void btnpc5_Click(object sender, EventArgs e)
        {
            Reloj5.Enabled = true;
            if (Reloj5.Enabled == true)
            {
                cont1 += 1;
                cont2 -= 1;
                groupBox1.Enabled = true;
                btn05.Enabled = true;
                label24.Text = "Ocupado";
            }
            lblocupado.Text = "Ocupado: "  +cont1.ToString("0");
            lbllibre.Text = "Libre: "  +cont2.ToString("0");

            if (numericUpDown1.Enabled == true || numericUpDown2.Enabled == true)
            {
                label24.Text = "Ocupado";
                label30.Text = label30.Text = hh5.ToString("0") + ":" + mm5.ToString("00") + ":" + ss5.ToString("00");
            }
        }

        private void Reloj6_Tick(object sender, EventArgs e)
        {
            dd6++;
            if (dd6 == 10)
            {
                dd6 = 0;
                ss6++;
                c6--;
                if (ss6 == 60)
                {
                    mm6++;
                    ss6 = 0;
                    c6 = 60;
                    costo6 += 0.05;
                    label47.Text = costo6.ToString();
                    if (mm6 == 60)
                    {
                        hh6++;
                        mm6 = 0;
                        costo_hora += 1.00;
                        lblhora.Text = costo_hora.ToString();
                    }
                }
            }
            label31.Text = hh6.ToString("0") + ":" + mm6.ToString("00") + ":" + ss6.ToString("00");
            int a6 = Convert.ToInt16(numericUpDown1.Text) - hh6;
            int b6 = Convert.ToInt16(numericUpDown2.Text) - mm6 - 1;
            label46.Text = (a6.ToString() + ":" + b6.ToString() + ":" + c6.ToString());
            if (a6 == 0 && b6 == -1)
            {
                label25.Text = "Libre";
                label46.Text = "0:0:0";
                Reloj6.Stop();
            }
        }

        private void btnpc6_Click(object sender, EventArgs e)
        {
            Reloj6.Enabled = true;
            if (Reloj6.Enabled == true)
            {
                cont1 += 1;
                cont2 -= 1;
                groupBox1.Enabled = true;
                btn06.Enabled = true;
                label25.Text = "Ocupado";
            }
            lblocupado.Text = "Ocupado: "   + cont1.ToString("0");
            lbllibre.Text = "Libre: "   + cont2.ToString("0");

            if (numericUpDown1.Enabled == true || numericUpDown2.Enabled == true)
            {
               

                label25.Text = "Ocupado";
                label31.Text = label31.Text = hh6.ToString("0") + ":" + mm6.ToString("00") + ":" + ss6.ToString("00");


            }
        }

        private void btn01_Click(object sender, EventArgs e)
        {
            Reloj1.Enabled = false;
            if (Reloj1.Enabled == false)
            {
                label14.Text = hh.ToString("0") + ":" + mm.ToString("00") + ":" + ss.ToString("00");
                texttotal.Text = Convert.ToString(costo1 + costo2 + costo3 + costo4 + costo5 + costo6);              
            }
            listBox1.Items.Add("Máquina 1 > " + costo1);
        }

        private void btn02_Click(object sender, EventArgs e)
        {
            Reloj2.Enabled = false;
            if (Reloj2.Enabled == false)
            {
                label33.Text = hh2.ToString("0") + ":" + mm2.ToString("00") + ":" + ss2.ToString("00");
                texttotal.Text = Convert.ToString(costo1 + costo2 + costo3 + costo4 + costo5 + costo6); 
            }
            listBox1.Items.Add("Máquina 2 > " + costo2);
        }

        private void btn03_Click(object sender, EventArgs e)
        {
            Reloj3.Enabled = false;
            if (Reloj3.Enabled == false)
            {
                label36.Text = hh3.ToString("0") + ":" + mm3.ToString("00") + ":" + ss3.ToString("00");
                texttotal.Text = Convert.ToString(costo1 + costo2 + costo3 + costo4 + costo5 + costo6); 
            }
            listBox1.Items.Add("Máquina 3 > " + costo3);
        }

        private void btn04_Click(object sender, EventArgs e)
        {
            Reloj4.Enabled = false;
            if (Reloj4.Enabled == false)
            {
                label39.Text = hh4.ToString("0") + ":" + mm4.ToString("00") + ":" + ss4.ToString("00");
                texttotal.Text = Convert.ToString(costo1 + costo2 + costo3 + costo4 + costo5 + costo6); 
            }
            listBox1.Items.Add("Máquina 4 > " + costo4);
        }

        private void btn05_Click(object sender, EventArgs e)
        {
            Reloj5.Enabled = false;
            if (Reloj5.Enabled == false)
            {
                label42.Text = hh5.ToString("0") + ":" + mm5.ToString("00") + ":" + ss5.ToString("00");
                texttotal.Text = Convert.ToString(costo1 + costo2 + costo3 + costo4 + costo5 + costo6); 
            }
            listBox1.Items.Add("Máquina 5 > " + costo5);
        }

        private void btn06_Click(object sender, EventArgs e)
        {
            Reloj6.Enabled = false;
            if (Reloj6.Enabled == false)
            {
                label45.Text = hh6.ToString("0") + ":" + mm6.ToString("00") + ":" + ss6.ToString("00");
                texttotal.Text = Convert.ToString(costo1 + costo2 + costo3 + costo4 + costo5 + costo6); 
            }
            listBox1.Items.Add("Máquina 6 > " + costo6);
        }

        private void btnsalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    
          
        }
}
